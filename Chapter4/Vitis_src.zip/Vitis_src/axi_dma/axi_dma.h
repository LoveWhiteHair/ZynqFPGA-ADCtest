#include "xaxidma.h"
#include "xparameters.h"
#include "xil_exception.h"
#include "xscugic.h"

#ifndef AXI_DMA_CFG_
#define AXI_DMA_CFG_

int check_data(int length, u8 start_value);
int axi_dma_cfg(void);
void rx_intr_handler(void *callback);
int axi_dma_start(u32 pkt_len);
int dma_setup_intr_system(XScuGic * int_ins_ptr);

#endif /* sccb_EMIO_CFG_ */
