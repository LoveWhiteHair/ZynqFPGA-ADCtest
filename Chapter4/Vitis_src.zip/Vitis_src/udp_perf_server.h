#ifndef __UDP_PERF_SERVER_H_
#define __UDP_PERF_SERVER_H_

#include "lwipopts.h"
#include "lwip/ip_addr.h"
#include "lwip/err.h"
#include "lwip/udp.h"
#include "lwip/inet.h"
#include "xil_printf.h"
#include "platform.h"

void udp_tx_data(u32 *buffer_ptr,unsigned int len);
void udp_SentData(uint32_t num, u8 * send_buff);
uint16_t udp_ReadData(uint8_t *buff);

/* seconds between periodic bandwidth reports */
#define INTERIM_REPORT_INTERVAL 5

/* server port to listen on/connect to */
#define UDP_CONN_PORT 5001

#endif /* __UDP_PERF_SERVER_H_ */
