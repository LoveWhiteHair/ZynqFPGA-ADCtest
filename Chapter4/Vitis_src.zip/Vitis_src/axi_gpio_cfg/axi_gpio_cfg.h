#include "xil_types.h"
#include "xgpio.h"

#ifndef AXI_GPIO_CFG_
#define AXI_GPIO_CFG_


void axi_gpio_init(void);
void axi_gpio_out0(void);
void axi_gpio_out1(void);
void axi_gpio_dma_ready(void);
void axi_gpio_dma_unready(void);
void axi_gpio_write(uint32_t output_result);
//u32 get_fifo_count(void);

#endif 

