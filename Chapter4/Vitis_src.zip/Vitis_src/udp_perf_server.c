#include <stdio.h>
#include <string.h>
#include "lwip/err.h"
#include "lwip/udp.h"
#include "xil_printf.h"
#include "lwip/inet.h"

struct udp_pcb *pcb;
struct udp_pcb *connected_pcb = NULL;
static struct pbuf *pbuf_to_be_sent = NULL;

static unsigned local_port = 9000;
static unsigned remote_port = 9000;
volatile unsigned udp_connected_flag = 0;

#define MAX_LEN    2500

uint8_t TxBuffer[MAX_LEN] = {0};
uint8_t RxBuffer[MAX_LEN] = {0};
uint16_t RxCount = 0;

//callback function
void udp_recv_callback(void *arg,struct udp_pcb *tpcb,struct pbuf *p, ip_addr_t *addr, u16_t port)
{
	struct pbuf *p_r;

    xil_printf("Received from %d.%d.%d.%d port %d\r\n", (addr->addr) & 0xFF,
    			(addr->addr>>8) & 0xFF, (addr->addr>>16) & 0xFF, (addr->addr>>24) & 0xFF, port);

    /* Tell the client that we have accepted it */
    //memcpy(RxBuffer,(unsigned char*)p->payload,p->len);
    //xil_printf("Received:%d,len=%d",RxBuffer,p->len);
    if(p != NULL)
	 {
				for(p_r = p; p_r != NULL; p_r = p_r->next)
			{
				 memcpy(RxBuffer,(unsigned char*)p_r->payload,p_r->len);
				 RxCount += p_r->len;
			}
	  }
    /* Free the p buffer */
    pbuf_free(p);
    return;
}
//receive data length count
uint16_t udp_ReadData(uint8_t *buff)
{
	uint16_t len = RxCount;
	if(len > 0)
		memcpy(buff,RxBuffer,len);
	memset(RxBuffer,0,len);
	RxCount = 0;
	return len;
}
//send received data
void udp_SentData(uint32_t num, u8 * send_buff)
{
	err_t err;
	struct udp_pcb *tpcb = connected_pcb;
		if (!tpcb) {
			xil_printf("error connect.\r\n");
		}

		pbuf_to_be_sent = pbuf_alloc(PBUF_TRANSPORT, num, PBUF_POOL);
		memset(pbuf_to_be_sent->payload, 0, num);
		memcpy(pbuf_to_be_sent->payload, (u8 *)send_buff, num);
		err = udp_send(tpcb, pbuf_to_be_sent);
		if (err != ERR_OK) {
			xil_printf("Error on udp send : %d\r\n", err);
			pbuf_free(pbuf_to_be_sent);
			return;
		}
		pbuf_free(pbuf_to_be_sent);
}
//print app title
void print_app_header()
{
    xil_printf("\r\n-----Network port UDP transmission adc sample data on upper computer ------\r\n");
}

//UDP send data function
void udp_tx_data(u32 *buffer_ptr,unsigned int len){
    static struct pbuf *ptr;

    ptr = pbuf_alloc(PBUF_TRANSPORT, len, PBUF_POOL); //apply for buffer

    if (ptr)
    {
        pbuf_take(ptr, buffer_ptr,len); /* package uffer_ptr data to pbuf */
        udp_send(pcb, ptr);              /* udp send data */
        pbuf_free(ptr);                  /* free pbuf */
    }
}

void start_application()
{

	err_t err;
	udp_connected_flag = 0;
    /* set client IP */

    ip_addr_t DestIPaddr;

    IP4_ADDR( &DestIPaddr,192,168,1,102);

    //create UDP PCB
    pcb = udp_new();
    if (!pcb) {
        xil_printf("Error creating PCB. Out of Memory\r\n");
        return;
    }

    //bind port
    err = udp_bind(pcb, IP_ADDR_ANY,local_port);//use client port 9000
    if (err != ERR_OK) {
        xil_printf("Unable to bind to port %d; err %d\r\n",
                local_port, err);
        udp_remove(pcb);
        return;
    }
    /* set client port */
    udp_connect(pcb, &DestIPaddr, remote_port);//use remote port 9000
    connected_pcb = pcb;
    udp_connected_flag = 1;
    xil_printf("UDP server started @ port %d\n\r", local_port);

	udp_recv(pcb, (udp_recv_fn)udp_recv_callback, NULL);  //bind receive function and callback function
	return 0;
}

