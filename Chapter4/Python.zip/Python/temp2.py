from datetime import datetime
from time import sleep

current_datetime = datetime.now()# 格式化为字符串，格式：年月日_时分秒
data_bytes_origin = b'\x01\x00\x0b\x00'
data_length_origin = len(data_bytes_origin)#总原始数据长度
origin_list = []
step=0
for i in range(0, data_length_origin, 4):
    four_bytes = data_bytes_origin[i:i + 4]
    hex_str = four_bytes.hex()
    origin_list.append(hex_str)
while True:
    step=step+1
    with open(f'test/all_data.txt', mode='a', newline='') as file:
        if step==1:
            file.write(f'{current_datetime}\n')
        file.writelines([item + '\n' for item in origin_list])
    sleep(1)