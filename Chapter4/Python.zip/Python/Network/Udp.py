import socket
import threading
import struct
import time
import csv

from PyQt5.QtCore import pyqtSignal
#from mainwindowlogic import *#UI界面逻辑功能和全局变量
from . import StopThreading


def get_host_ip() -> str:
    """获取本机IP地址"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]

        #hostname = socket.gethostname()
        #ip = socket.gethostbyname(hostname)

    finally:
        s.close()
    return ip

def get_board_ip():
    hostname = socket.gethostname()
    board_ip = socket.gethostbyname(hostname)
    return board_ip

class UdpLogic():
    udp_signal_write_msg = pyqtSignal(str)
    udp_signal_write_info = pyqtSignal(str, int,int)#for str
    #udp_signal_write_info = pyqtSignal(bytes, int, int)#for bytes
    plot_signal_data_info = pyqtSignal(bytes)#bytes数据，接收数据（字节）
    udp_signal_len_info = pyqtSignal(int)#int数据，接收数据长度（字节）


    def __init__(self):
        #super().__init__(parent)
        self.new_link = 0
        self.step = 0
        self.sever_tr = None
        self.sever_rx = None
        self.plot_bytes_total = None
        self.plot_byte = 0
        self.need_byte = 0
        self.send_address = None
        self.num_cnt = 0#接收字节数counter
        self.int_info = None
        self.rx_num = None
        self.link_flag = False#udp连接状态
        self.udp_socket = None#udp嵌套字
        self.last_checked_value = None  # 用于保存每一波数据的最后一个检测值
        self.plot_time=2#每张图的横轴时间

    def udp_server_start(self, my_ip: str,target_ip: str,my_port: int,target_port: int,time_step:int,fs,xlen,new_link:int) -> None:
        """
        开启UDP服务端
        """
        #self.plot_time=time_step
        self.udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)#建立UDP套接字
        self.udp_socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 1024 * 1024)#设置接收缓冲区大小为1MB
        self.plot_time=int(xlen)
        self.step=0
        my_port = int(my_port)
        my_address = (my_ip, my_port)
        target_port=int(target_port)
        self.new_link=int(new_link)
        self.send_address = (target_ip, target_port)
        self.udp_socket.bind(my_address)
        self.sever_rx = threading.Thread(target=self.udp_server_concurrency)
        self.sever_rx.start()
        msg = "UDP服务端正在监听端口:{}\n".format(my_port)
        self.udp_signal_write_msg.emit(msg)
        msg = "当前设置的刷新频率:{}s\n".format(time_step)
        self.udp_signal_write_msg.emit(msg)
        msg = "当前设置的采样频率:{}Hz\n".format(fs)
        self.udp_signal_write_msg.emit(msg)
        msg = "开启了一次新的连接:{}\n".format(bool(self.new_link))
        self.udp_signal_write_msg.emit(msg)
        self.need_byte = int(4*12*fs*time_step)
        self.plot_byte = int(4*12*fs*self.plot_time)#总的需求字节为4字节*12通道*采样率*3s
        msg = "计算每次需要接收的字节数4字节*8通道*fs*刷新时间={}bytes\n".format(self.need_byte)
        self.udp_signal_write_msg.emit(msg)
        self.plot_bytes_total = bytearray()#初始化画图列表
        print("plot_bytes_total initialized")
    def udp_server_concurrency(self) -> None:
        """
        用于创建一个线程持续监听UDP通信
        """

        while True:#持续接收数据
            time1 = time.perf_counter()  # 接收开始时间
            total_bytes_info = b''#最终的bytes数据
            total_info = '' #最终字符串
            self.num_cnt = 0#函数内部计数变量


            while self.num_cnt<self.need_byte-1023:
                recv_msg, recv_addr = self.udp_socket.recvfrom(1024)
                if self.num_cnt == 0:
                    msg = f"来自IP:{recv_addr[0]}端口:{recv_addr[1]}:"
                    self.udp_signal_write_msg.emit(msg)  # 当前监听地址和端口号
                info = recv_msg.hex() #HEX解码
                bytes_info = bytes.fromhex(info)# 将字符串转换为hex格式bytes数据
                #确保数据从11channel开始
                if self.new_link==1:
                    print('new link info:',bytes_info)
                    target_value = 11  # 要查找的起始目标字节值
                    target_index = None  # 用于记录目标字节的索引
                    # 遍历bytes_info，检查索引为2、5、8等位置的字节值
                    for i in range(2, len(bytes_info), 4):  # 从索引2开始，每隔3个位置检查一次
                        if bytes_info[i] == target_value:  # 检查当前字节是否为目标值
                            target_index = i
                            print('find target value,index=', target_index)
                            self.new_link=0#找到数据，退出数据头部查找
                            break  # 找到目标值后退出循环
                    if target_index is not None:
                        # 计算新的起始索引（坐标-2）
                        new_start_index = max(0, target_index - 2)  # 确保起始索引不小于0
                        # 截取从new_start_index到末尾的数据
                        bytes_info = bytes_info[new_start_index:]#对输出进行切割，确保第一组是想要的首位数据
                        print('cut bytes', bytes_info)
                  
                rx_num_once = len(bytes_info)  # 读取本次接收的数据长度（字节）
                self.num_cnt =self.num_cnt + rx_num_once#统计总的接收数据
                total_bytes_info += bytes_info
                total_info += info

            #数据连续性检测
            print('new data collected')
            error_flag=0
            error_index = -1
            for i in range(6, len(total_bytes_info), 4):  # 从索引6开始，步长为4
                previous_value = total_bytes_info[i - 4]  # 上一数的值
                current_value = total_bytes_info[i]  # 当前值
                if i==6 and self.last_checked_value is not None:
                    if not (previous_value == (self.last_checked_value + 1) % 12):
                        error_index = i-4
                        print('find error data at location:', error_index)
                        print('last channel',self.last_checked_value)
                        print('current channel',previous_value)
                self.last_checked_value = current_value  # 更新最后一个检测值
                # 检查当前值是否比上一次的值多1
                if not (current_value == (previous_value + 1) % 12):
                    error_index = i
                    print('find error data at location:', error_index)
                    print('last channel', previous_value)
                    print('current channel', current_value)


            # 如果检测到错误，从错误位置开始继续检测，直到找到新的值为 11 的位置（新的一组数据）
            if error_index != -1:
                self.plot_bytes_total=bytearray()#初始化画图列表
                print('error find,refresh plot_bytes_total')
                print('start new data cut')
                target_index = None
                for i in range(error_index, len(total_bytes_info), 4):  # 从错误位置开始，步长为4,寻找新的一组数据
                    if total_bytes_info[i] == 11:  # 检查当前字节是否为 11
                        print('find target value, index=', i)
                        target_index = i
                        break  # 找到目标值后退出循环
                if target_index is not None:
                    # 计算新的起始索引（坐标-2）
                    new_start_index = max(0, target_index - 2)  # 确保起始索引不小于0
                    # 截取从new_start_index到末尾的数据
                    total_bytes_info = total_bytes_info[new_start_index:]  # 对输出进行切割，确保第一组是想要的首位数据
                    print('cut total bytes', total_bytes_info.hex())
                if target_index is None:
                    self.new_link = 1  # 如果本次没有检测到新的开始轮次，禁用传输，重新开始新的接收
                    self.last_checked_value = None



            # 输出信息
            if self.new_link==0:#只有确保完成了数据切割与检测后才将数据输出
                self.step = self.step + 1
                self.udp_signal_len_info.emit(self.num_cnt)#发送总的接收到的字节数量给数据显示模块
                self.plot_signal_data_info.emit(total_bytes_info)#向画图函数传递接收到的bytes数据
                print("本次接收长度", self.num_cnt)
                self.num_cnt = 0  # 清零计数
                time2 = time.perf_counter()  # 接收完成时间
                print("接收数据耗时", time2 - time1)
            if self.new_link==1:
                print('数据异常，本次传输禁用')



    def udp_send(self, send_info: str) -> None:
        """
        功能函数，用于UDP客户端发送消息
        """
        try:
            send_info_encoded = send_info.encode("utf-8")
            self.udp_socket.sendto(send_info_encoded, self.send_address)
            msg = "UDP客户端已发送"
            self.udp_signal_write_msg.emit(msg)
            self.udp_signal_write_info.emit(send_info, self.InfoSend,0)
        except Exception as ret:
            msg = "发送失败\n"
            self.udp_signal_write_msg.emit(msg)


    def udp_close(self) -> None:
        """
        功能函数，关闭网络连接的方法
        """
        if self.link_flag == self.ServerUDP:
            try:
                self.udp_socket.close()
                msg = "已断开网络\n"
                self.udp_signal_write_msg.emit(msg)
            except Exception as ret:
                pass

            try:
                StopThreading.stop_thread(self.sever_rx)
            except Exception:
                pass


    NoLink = -1
    ServerUDP = 2
    ClientUDP = 3
    InfoSend = 0
    InfoRec = 1
