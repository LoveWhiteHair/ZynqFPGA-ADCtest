import math
a=1.7672-1.5875
print('a:',a)
b=1.7222-1.6319
print('b',b)
c=1.6931-1.6103
print('c',c)
db=20*math.log(a/b)
print('db:',db)