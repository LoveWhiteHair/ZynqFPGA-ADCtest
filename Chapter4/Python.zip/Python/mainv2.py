import csv
import math
import os
from signal import signal

from PyQt5.QtWidgets import QApplication,QGridLayout
from PyQt5 import QtCore
import socket
import sys
import threading



#user file
import MainWindowUI
from mainwindowlogic import *#UI界面逻辑功能和len_signal全局变量
from Network import NetworkLogic #Network库，内部定义了UDP逻辑
#画图
import numpy as np
import matplotlib.pyplot as plt
import struct
import scipy.signal
import time
from datetime import datetime
from UI.MyWidgets import MyFigure



class MainWindow(WidgetLogic, NetworkLogic):
    def __init__(self, parent=None):
        super().__init__(parent)
        #检测屏幕分辨率
        self.new_link_signal = 0
        self.desktop = QApplication.desktop()
        self.screenRect = self.desktop.screenGeometry()
        self.screenheight = self.screenRect.height()
        self.screenwidth = self.screenRect.width()
        self.height = int(self.screenheight * 0.7)
        self.width = int(self.screenwidth * 0.7)
        print("Screen height {}".format(self.screenheight))
        print("Screen width {}".format(self.screenwidth))
        self.resize(self.width, self.height)



        self.time_step = 0
        self.input_fs = 0


        self.plot_flag=1


        self.link_signal.connect(self.link_signal_handler)#连接至udp服务器
        self.disconnect_signal.connect(self.disconnect_signal_handler)#关闭连接
        self.send_signal.connect(self.send_signal_handler)#数据发送模块
        self.udp_signal_write_msg.connect(self.msg_write)#udp连接信息显示
        self.udp_signal_write_info.connect(self.info_write)#udp接收数据显示
        self.udp_signal_len_info.connect(self.len_write)#udp接收长度label显示
        self.plot_signal_data_info.connect(self.data_process)#接收画图数据被触发后进行画图函数



    def link_signal_handler(self, signal) -> None:
        """
        启动UDP server连接
        """
        link_type, my_ip, target_ip,my_port,target_port,self.time_step,self.input_fs,xlen,self.new_link_signal = signal
        if link_type == self.ServerUDP:
            self.udp_server_start(my_ip, target_ip,my_port,target_port,self.time_step,self.input_fs,xlen,self.new_link_signal)


    def disconnect_signal_handler(self) -> None:
        """关闭UDP server连接"""
        if self.link_flag == self.ServerUDP:
            self.udp_close()

    def send_signal_handler(self, msg: str) -> None:
        """发送按钮的槽函数"""
        if self.link_flag == self.ServerUDP:
            self.udp_send(msg)
            self.SendCounter = self.SendCounter+1
        self.counter_signal.emit(self.ReceiveCounter,self.SendCounter)


    def closeEvent(self, event) -> None:
        """
        重写closeEvent方法，实现MainWindow窗体关闭时执行一些代码
        :param event: close()触发的事件
        """
        self.disconnect_signal_handler()




    def data_process(self,data_bytes_origin):
        current_datetime = datetime.now()# 格式化为字符串，格式：年月日_时分秒
        formatted_datetime = current_datetime.strftime("%Y%m%d_%H%M%S")
        data_save_path = f'data_trans/fs{self.input_fs}/xlen{self.plot_time}/step{self.time_step}'
        if not os.path.exists(data_save_path):
            os.makedirs(data_save_path)
        print("current step",self.step)
        time_label1 = time.perf_counter()
        data_length_origin = len(data_bytes_origin)#总原始数据长度
        origin_list = []
        for i in range(0, data_length_origin, 4):
            four_bytes = data_bytes_origin[i:i + 4]
            hex_str = four_bytes.hex()
            origin_list.append(hex_str)
        with open(f'{data_save_path}/all_data.txt', mode='a', newline='') as file:
            if self.step==1:
                file.write(f'{current_datetime}\n')
            file.writelines([item + '\n' for item in origin_list])
        if self.plot_byte < data_length_origin:
            # 如果 self.plot_byte 小于 data_length_origin，直接用新的数据覆盖
            self.plot_bytes_total = data_bytes_origin
        else:
            # 如果 self.plot_byte 大于或等于 data_length_origin，舍弃老的数据
            self.plot_bytes_total = self.plot_bytes_total[-(self.plot_byte - data_length_origin):] + data_bytes_origin
        print('self.plot_byte=',self.plot_byte)
        print('data_length_origin=', data_length_origin)
        plot_bytes=self.plot_bytes_total
        '''
        #数据去头
        target_value = 11  # 要查找的起始目标字节值
        target_index = None  # 用于记录目标字节的索引
        # 遍历bytes_info，检查索引为2、5、8等位置的字节值
        for i in range(2, len(plot_bytes), 4):  # 从索引2开始，每隔3个位置检查一次
            if plot_bytes[i] == target_value:  # 检查当前字节是否为目标值
                target_index = i
                print('find target value,index=', target_index)
                break  # 找到目标值后退出循环
        if target_index is not None:
            # 计算新的起始索引（坐标-2）
            new_start_index = max(0, target_index - 2)  # 确保起始索引不小于0
            # 截取从new_start_index到末尾的数据
            plot_bytes = plot_bytes[new_start_index:]  # 对输出进行切割，确保第一组是想要的首位数据
        '''
        print('len(plot_bytes)',len(plot_bytes))
        if len(plot_bytes) == 0:
            print("plot_bytes 的长度为 0，退出函数")
            return  # 退出当前函数
        # 保存原始信息
        hex_list = []
        for i in range(0, len(plot_bytes), 4):
            four_bytes = plot_bytes[i:i + 4]
            hex_str = four_bytes.hex()
            hex_list.append(hex_str)
        with open(f'{data_save_path}/{formatted_datetime} origin_data.txt', mode='w', newline='') as file:
            file.write(f'run{self.step}' + '\n')
            file.writelines([item + '\n' for item in hex_list])
        data_length=int(len(plot_bytes)/4)#数据量总长度
        #数据转换
        reg_arr_high = [b'' for _ in range(12)]  # 定义12个空列表用来存放reg中的高8位bytes
        reg_arr_low = [b'' for _ in range(12)]  # 定义12个空列表用来存放reg中的低8位bytes
        reg_cnt = [0] * 12  # 12个0元素的列表，用来记录每个寄存器的数据量
        dout_arr = [b'' for _ in range(8)]  # 定义8个空列表用来放输出int数据
        dout = [[] for _ in range(8)]
        data_index = 0  # 扫描初始bytes数组的索引
        for i in range(0, data_length):
            current_channel = int.from_bytes(plot_bytes[2 + 4 * i:2 + 4 * i + 2], 'little')
            current_channel = (current_channel + 1) % 12  # 加1整除12，调整channel位置（不需要时删去）
            # print('current channel',current_channel)
            low_bytes = plot_bytes[data_index:data_index + 1]  # 通道对应的数据字节
            high_bytes = plot_bytes[data_index + 1:data_index + 1 + 1]  # 通道对应的数据字节
            data_index += 4
            reg_cnt[current_channel] += 1  # 对应通道的计数器+1
            reg_arr_high[current_channel] += high_bytes
            reg_arr_low[current_channel] += low_bytes

        for i in range(0, min(reg_cnt)):
            # DOUT_0 = REG22低位 + REG21高位 + REG21低位
            dout_arr[0] += bytes([reg_arr_low[1][i]])
            dout_arr[0] += bytes([reg_arr_high[0][i]])
            dout_arr[0] += bytes([reg_arr_low[0][i]])
            # DOUT_1 = REG23高位 + REG23低位 + REG22高位
            dout_arr[1] += bytes([reg_arr_high[2][i]])
            dout_arr[1] += bytes([reg_arr_low[2][i]])
            dout_arr[1] += bytes([reg_arr_high[1][i]])
            # DOUT_2 = REG25低位 + REG24高位 + REG24低位
            dout_arr[2] += bytes([reg_arr_low[4][i]])
            dout_arr[2] += bytes([reg_arr_high[3][i]])
            dout_arr[2] += bytes([reg_arr_low[3][i]])
            # DOUT_3 = REG26高位 + REG26低位 + REG25高位
            dout_arr[3] += bytes([reg_arr_high[5][i]])
            dout_arr[3] += bytes([reg_arr_low[5][i]])
            dout_arr[3] += bytes([reg_arr_high[4][i]])
            # DOUT_4 = REG28低位 + REG27高位 + REG27低位
            dout_arr[4] += bytes([reg_arr_low[7][i]])
            dout_arr[4] += bytes([reg_arr_high[6][i]])
            dout_arr[4] += bytes([reg_arr_low[6][i]])
            # DOUT_5 = REG29高位 + REG29低位 + REG28高位
            dout_arr[5] += bytes([reg_arr_high[8][i]])
            dout_arr[5] += bytes([reg_arr_low[8][i]])
            dout_arr[5] += bytes([reg_arr_high[7][i]])
            # DOUT_6 = REG31低位 + REG30高位 + REG30低位
            dout_arr[6] += bytes([reg_arr_low[10][i]])
            dout_arr[6] += bytes([reg_arr_high[9][i]])
            dout_arr[6] += bytes([reg_arr_low[9][i]])
            # DOUT_7 = REG32高位 + REG32低位 + REG31高位
            dout_arr[7] += bytes([reg_arr_high[11][i]])
            dout_arr[7] += bytes([reg_arr_low[11][i]])
            dout_arr[7] += bytes([reg_arr_high[10][i]])
        for i in range(0, 8):
            for j in range(0, len(dout_arr[i]), 3):  # 每次取3个字节
                # 提取 i 到 i+3 的字节片段，转换为整数
                int_val = int.from_bytes(dout_arr[i][j:j + 3], byteorder='big')
                dout[i].append(int_val)
        time_label2 = time.perf_counter()
        print('数据转换运行时间:', time_label2 - time_label1, 's')

        #画图相关参数设置
        data_length = self.input_fs * self.plot_time#总的画图长度
        data_length = int(data_length)
        data_length = min(data_length,min(reg_cnt))#画图长度取希望的总画图长度与当前已有长度的最小值
        print("当前画图长度",data_length/self.input_fs,'s')



        #画图函数
        if self.plot_flag==1 :
            #画图空闲时开始画图，画布初始化
            self.plot_flag=0
            time_label1 = time.perf_counter()
            self.fig1.clf()  # 清理画布
            self.fig2.clf()  # 清理画布
            ax1 = self.fig1.subplots(2, 2, sharey=False)
            ax2 = self.fig2.subplots(2, 2, sharey=False)
            ax1 = ax1.ravel()
            ax2 = ax2.ravel()
            time_label = np.linspace(0, data_length - 1, data_length) * 1 / self.input_fs

            for channel_index in range(0, 4):  # 通道0到通道3
                scan_arr = dout[channel_index][-data_length:]#取数组的最后data_length位
                scan_byte = dout_arr[channel_index][-data_length*3:]
                scan_arr = np.array(scan_arr)
                ax1[channel_index].cla()
                ax1[channel_index].plot(time_label, scan_arr*3.6/2**24 , 'k-')
                ax1[channel_index].set_title(f'channel{channel_index}')
                hex_list = []
                for i in range(0, len(scan_byte), 3):
                    three_bytes = scan_byte[i:i + 3]
                    hex_str = three_bytes.hex()
                    hex_list.append(hex_str)
                for ax in ax1.flat:
                    ax.set(xlabel='Time/s', ylabel='Voltage/V')
                with open(f'{data_save_path}/{formatted_datetime}dout_arr_channel{channel_index}.txt', mode='w', newline='') as file:
                    file.write(f'run{self.step}' + '\n')
                    file.writelines([item + '\n' for item in hex_list])
                with open(f'{data_save_path}/{formatted_datetime}dout_channel{channel_index}.txt', mode='w', newline='') as file:
                    file.write(f'run{self.step}' + '\n')
                    file.writelines([str(item) + '\n' for item in scan_arr])


            for channel_index in range(4, 8):  # 通道4到通道7
                scan_arr = dout[channel_index][-data_length:]#取数组的最后data_length位
                scan_byte = dout_arr[channel_index][-data_length * 3:]
                scan_arr = np.array(scan_arr)
                ax2[channel_index-4].cla()
                ax2[channel_index-4].plot(time_label, scan_arr*3.6/2**24 , 'k-')
                ax2[channel_index-4].set_title(f'channel{channel_index}')
                hex_list = []
                for i in range(0, len(scan_byte), 3):
                    three_bytes = scan_byte[i:i + 3]
                    hex_str = three_bytes.hex()
                    hex_list.append(hex_str)
                for ax in ax2.flat:
                    ax.set(xlabel='Time/s', ylabel='Voltage/V')
                with open(f'{data_save_path}/{formatted_datetime}dout_arr_channel{channel_index}.txt', mode='w', newline='') as file:
                    file.write(f'run{self.step}' + '\n')
                    file.writelines([item + '\n' for item in hex_list])
                with open(f'{data_save_path}/{formatted_datetime}dout_channel{channel_index}.txt', mode='w', newline='') as file:
                    file.write(f'run{self.step}' + '\n')
                    file.writelines([str(item) + '\n' for item in scan_arr])

            self.fig1.canvas.draw()  # 这里注意是画布重绘，self.figs.canvas
            self.fig1.canvas.flush_events()  # 画布刷新self.figs.canvas
            self.fig2.canvas.draw()  # 这里注意是画布重绘，self.figs.canvas
            self.fig2.canvas.flush_events()  # 画布刷新self.figs.canvas
            time_label2 = time.perf_counter()
            print('画图运行时间:', time_label2 - time_label1, 's')
            self.plot_flag = 1

if __name__ == '__main__':
    QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling)#高分辨率适应
    app = QApplication(sys.argv)  # 在 QApplication 方法中使用，创建应用程序对象
    myWin = MainWindow()  # 实例化 MyMainWindow 类，创建主窗口
    myWin.show()  # 在桌面显示控件 myWin
    sys.exit(app.exec_())  # 结束进程，退出程序