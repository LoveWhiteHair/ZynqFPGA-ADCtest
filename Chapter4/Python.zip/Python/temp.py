plot_bytes_total = bytearray()
print(plot_bytes_total)  # 输出：b''
print(len(plot_bytes_total))  # 输出：0

data_bytes_origin = b'\x01\x00\x0b\x00'#DOUT_0<15:0>
plot_byte=48
data_length_origin=len(data_bytes_origin)
for i in range(0,20):
    plot_bytes_total=plot_bytes_total[-(plot_byte-data_length_origin):]+data_bytes_origin
    print(plot_bytes_total)
    print(len(plot_bytes_total))