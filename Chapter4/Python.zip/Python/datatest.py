import os
import csv
import numpy as np
import struct
import time
from datetime import datetime



#生成测试用bytes串
step=0
bytes1 = b'\x01\x00\x0b\x00'#DOUT_0<15:0>
bytes2 = b'\x00\x02\x00\x00'#DOUT_1<7:0>,DOUT_0<23:16>
bytes3 = b'\x00\x00\x01\x00'#DOUT_1<23:8>
bytes4 = b'\x03\x00\x02\x00'#DOUT_2<15:0>
bytes5 = b'\x00\x04\x03\x00'#DOUT_3<7:0>,DOUT_2<23:16>
bytes6 = b'\x00\x00\x04\x00'#DOUT_3<23:8>
bytes7 = b'\x05\x00\x05\x00'#DOUT_4<15:0>
bytes8 = b'\x00\x06\x06\x00'#DOUT_5<7:0>,DOUT_4<23:16>
bytes9 = b'\x00\x00\x07\x00'#DOUT_5<23:8>
bytes10 = b'\x07\x00\x08\x00'#DOUT_6<15:0>
bytes11 = b'\x00\x08\x09\x00'#DOUT_7<7:0>,DOUT_6<23:16>
bytes12 = b'\x00\x00\x0a\x00'#DOUT_7<23:8>
bytes_array = bytearray()
bytes_array.extend(bytes1)
bytes_array.extend(bytes2)
bytes_array.extend(bytes3)
bytes_array.extend(bytes4)
bytes_array.extend(bytes5)
bytes_array.extend(bytes6)
bytes_array.extend(bytes7)
bytes_array.extend(bytes8)
bytes_array.extend(bytes9)
bytes_array.extend(bytes10)
bytes_array.extend(bytes11)
bytes_array.extend(bytes12)
bytes_array.extend(bytes1)
bytes_array.extend(bytes2)
bytes_array.extend(bytes3)
bytes_array.extend(bytes4)
bytes_array.extend(bytes5)
bytes_array.extend(bytes6)
bytes_array.extend(bytes7)
bytes_array.extend(bytes8)
bytes_array.extend(bytes9)
bytes_array.extend(bytes10)
bytes_array.extend(bytes11)
bytes_array.extend(bytes12)
result_bytes = bytes(bytes_array)

time1 = time.perf_counter()  # 开始时间
plot_bytes=result_bytes
data_length=int(len(plot_bytes)/4)#数据量总长度
print('test_bytes',result_bytes.hex())
reg_arr_high = [b'' for _ in range(12)]  # 定义12个空列表用来存放reg中的高8位bytes
reg_arr_low = [b'' for _ in range(12)]  # 定义12个空列表用来存放reg中的低8位bytes
reg_cnt = [0] * 12  # 12个0元素的列表，用来记录每个寄存器的数据量

dout_arr=[b'' for _ in range(8)]# 定义8个空列表用来放输出int数据
dout=[[] for _ in range(8)]


data_index = 0#扫描初始bytes数组的索引
for i in range(0, data_length):
    current_channel = int.from_bytes(plot_bytes[2 + 4 * i:2 + 4 * i + 2], 'little')
    current_channel = (current_channel + 1) % 12#加1整除12，调整channel位置（不需要时删去）
    #print('current channel',current_channel)
    low_bytes = plot_bytes[data_index:data_index + 1]  # 通道对应的数据字节
    high_bytes = plot_bytes[data_index+1:data_index+1 + 1]  # 通道对应的数据字节
    data_index += 4
    reg_cnt[current_channel] += 1  # 对应通道的计数器+1
    reg_arr_high[current_channel] +=high_bytes
    reg_arr_low[current_channel] += low_bytes




for i in range(0,min(reg_cnt)):
    # DOUT_0 = REG22低位 + REG21高位 + REG21低位
    dout_arr[0] += bytes([reg_arr_low[1][i]])
    dout_arr[0] += bytes([reg_arr_high[0][i]])
    dout_arr[0] += bytes([reg_arr_low[0][i]])

    # DOUT_1 = REG23高位 + REG23低位 + REG22高位
    dout_arr[1] += bytes([reg_arr_high[2][i]])
    dout_arr[1] += bytes([reg_arr_low[2][i]])
    dout_arr[1] += bytes([reg_arr_high[1][i]])

    # DOUT_2 = REG25低位 + REG24高位 + REG24低位
    dout_arr[2] += bytes([reg_arr_low[4][i]])
    dout_arr[2] += bytes([reg_arr_high[3][i]])
    dout_arr[2] += bytes([reg_arr_low[3][i]])

    # DOUT_3 = REG26高位 + REG26低位 + REG25高位
    dout_arr[3] += bytes([reg_arr_high[5][i]])
    dout_arr[3] += bytes([reg_arr_low[5][i]])
    dout_arr[3] += bytes([reg_arr_high[4][i]])

    # DOUT_4 = REG28低位 + REG27高位 + REG27低位
    dout_arr[4] += bytes([reg_arr_low[7][i]])
    dout_arr[4] += bytes([reg_arr_high[6][i]])
    dout_arr[4] += bytes([reg_arr_low[6][i]])

    # DOUT_5 = REG29高位 + REG29低位 + REG28高位
    dout_arr[5] += bytes([reg_arr_high[8][i]])
    dout_arr[5] += bytes([reg_arr_low[8][i]])
    dout_arr[5] += bytes([reg_arr_high[7][i]])

    # DOUT_6 = REG31低位 + REG30高位 + REG30低位
    dout_arr[6] += bytes([reg_arr_low[10][i]])
    dout_arr[6] += bytes([reg_arr_high[9][i]])
    dout_arr[6] += bytes([reg_arr_low[9][i]])

    # DOUT_7 = REG32高位 + REG32低位 + REG31高位
    dout_arr[7] += bytes([reg_arr_high[11][i]])
    dout_arr[7] += bytes([reg_arr_low[11][i]])
    dout_arr[7] += bytes([reg_arr_high[10][i]])

for i in range(0,8):
    for j in range(0, len(dout_arr[i]), 3):  # 每次取3个字节
        # 提取 i 到 i+3 的字节片段，转换为整数
        int_val = int.from_bytes(dout_arr[i][j:j+3], byteorder='big')
        dout[i].append(int_val)
time2 = time.perf_counter()  # 完成时间
print('spend time',time2-time1)
print(dout_arr)
print(dout)



current_datetime = datetime.now()
# 格式化为字符串，格式：年月日_时分秒
formatted_datetime = current_datetime.strftime("%Y%m%d_%H%M%S")
print("用于文件名的日期时间字符串:", formatted_datetime)

hex_list = []
for i in range(0, len(plot_bytes), 4):
    four_bytes = plot_bytes[i:i + 4]
    hex_str = four_bytes.hex()
    hex_list.append(hex_str)
with open(f'test/{formatted_datetime}test.txt', mode='w', newline='') as file:
    file.write(f'run{step}' + '\n')
    file.writelines([item + '\n' for item in hex_list])

three_bytes=dout_arr[0][0:3]
print(three_bytes)
hex_str = three_bytes.hex()
hex_list.append(hex_str)

for channel_index in range(0, 4):  # 通道0到通道3
    hex_list=[]
    scan_byte = dout_arr[channel_index]
    scan_arr = dout[channel_index]
    for i in range(0, len(scan_byte), 3):
        three_bytes = scan_byte[i:i + 3]
        hex_str = three_bytes.hex()
        hex_list.append(hex_str)
    with open(f'test/{formatted_datetime}test_dout_arr_channel{channel_index}.txt', mode='w', newline='') as file:
        file.write(f'run{step}' + '\n')
        file.writelines([item + '\n' for item in hex_list])
    with open(f'test/{formatted_datetime}test_dout_channel{channel_index}.txt', mode='w', newline='') as file:
        file.write(f'run{step}' + '\n')
        file.writelines([str(item) + '\n' for item in scan_arr])

bytes_info=result_bytes
new_link=1
target_value = 11  # 要查找的目标字节值
target_index = None  # 用于记录目标字节的索引
# 遍历bytes_info，检查索引为2、5、8等位置的字节值
for i in range(2, len(bytes_info), 4):  # 从索引2开始，每隔3个位置检查一次
    #print('current i:',i)
    if bytes_info[i] == target_value:  # 检查当前字节是否为目标值
        print('find target value,i=',i)
        target_index = i
        new_link=0
        break  # 找到目标值后退出循环
#print('result_bytes[1:]',result_bytes[1:])
print('target index',target_index)
print('bytes_info[i]:',bytes_info[5])
if target_index is not None:
    result_bytes=result_bytes[target_index-2:]
    print('cut bytes',result_bytes.hex())


total_bytes_info=result_bytes

#数据连续性检测
error_flag=0
error_index = -1
last_checked_value = 9
for i in range(6, len(total_bytes_info), 4):  # 从索引6开始，步长为4
    previous_value = total_bytes_info[i-4]  # 上一数的值
    #print('previous_value',previous_value)
    current_value = total_bytes_info[i]  # 当前值
    #print('current_value', current_value)
    if i == 6 and last_checked_value is not None:
        if not (previous_value == (last_checked_value + 1) % 12):
            error_index = i - 4
            print('find error data at location:', error_index)
            print('last channel', last_checked_value)
            print('current channel', previous_value)
            error_flag = 1
    last_checked_value = current_value  # 更新最后一个检测值
    # 检查当前值是否比上一次的值多1
    if not (current_value == (previous_value + 1) % 12):
        error_index = i
        print('find error data at location:', error_index)
        print('last channel', previous_value)
        print('current channel', current_value)
        error_flag = 1

if error_index != -1:# 如果检测到错误，从错误位置开始继续检测，直到找到新的值为 11 的位置（新的一组数据）
    print('start new data cut')
    target_index = None
    for i in range(error_index, len(total_bytes_info), 4):  # 从错误位置的下一个位置开始，步长为4
        if total_bytes_info[i] == 11:  # 检查当前字节是否为 11
            print('find target value, index=', i)
            target_index = i
            break  # 找到目标值后退出循环
    if target_index is not None:
        # 计算新的起始索引（坐标-2）
        new_start_index = max(0, target_index - 2)  # 确保起始索引不小于0
        # 截取从new_start_index到末尾的数据
        total_bytes_info = total_bytes_info[new_start_index:]  # 对输出进行切割，确保第一组是想要的首位数据
        print('cut total bytes', total_bytes_info.hex())
    if target_index is  None:
        new_link = 1#如果本次没有检测到新的开始轮次，禁用传输，重新开始新的接收
'''
一组48字节
channel0 ch11 REG21 = [];%DOUT_0<15:0>
channel1 ch0 REG22 = [];%DOUT_1<7:0>,DOUT_0<23:16>
channel2 ch1 REG23 = [];%DOUT_1<23:8>
channel3 ch2 REG24 = [];%DOUT_2<15:0>
channel4 ch3 REG25 = [];%DOUT_3<7:0>,DOUT_2<23:16>
channel5 ch4 REG26 = [];%DOUT_3<23:8>
channel6 ch5 REG27 = [];%DOUT_4<15:0>
channel7 ch6 REG28 = [];%DOUT_5<7:0>,DOUT_4<23:16>
channel8 ch7 REG29 = [];%DOUT_5<23:8>
channel9 ch8 REG30 = [];%DOUT_6<15:0>
channel10 ch9 REG31 = [];%DOUT_7<7:0>,DOUT_6<23:16>
channel11 ch10 REG32 = [];%DOUT_7<23:8>
'''


