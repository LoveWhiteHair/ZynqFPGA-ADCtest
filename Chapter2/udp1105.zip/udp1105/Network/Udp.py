import socket
import threading
import struct
import time

from PyQt5.QtCore import pyqtSignal
from . import StopThreading


def get_host_ip() -> str:
    """获取本机IP地址"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]

        #hostname = socket.gethostname()
        #ip = socket.gethostbyname(hostname)

    finally:
        s.close()
    return ip

def get_board_ip():
    hostname = socket.gethostname()
    board_ip = socket.gethostbyname(hostname)
    return board_ip

class UdpLogic:
    udp_signal_write_msg = pyqtSignal(str)
    udp_signal_write_info = pyqtSignal(str, int,int)#for str
    #udp_signal_write_info = pyqtSignal(bytes, int, int)#for bytes
    plot_signal_data_info = pyqtSignal(int)#int数据，接收数据长度（字节）
    udp_signal_len_info = pyqtSignal(int)#int数据，接收数据长度（字节）
    udp_save_str_info = pyqtSignal(str)#接收到的str格式数据

    def __init__(self):
        self.send_address = None
        self.num_cnt = 0#接收字节数counter
        self.int_info = None
        self.rx_num = None
        self.link_flag = False#udp连接状态
        self.udp_socket = None#udp嵌套字
        self.sever_th = None
        self.data_byte = 0#想要接收的字节数

    def udp_server_start(self, ip: str,port: int,data_len: int) -> None:
        """
        开启UDP服务端
        """

        self.udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)#建立UDP套接字
        self.udp_socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 1024 * 1024)#设置接收缓冲区大小为1MB
        port = int(port)
        address = (ip, port)
        self.udp_socket.bind(address)
        self.sever_th = threading.Thread(target=self.udp_server_concurrency)
        self.sever_th.start()
        msg = "UDP服务端正在监听端口:{}\n".format(port)
        self.udp_signal_write_msg.emit(msg)
        msg = "当前设置的接收字节数:{}bytes\n".format(data_len)
        self.data_byte = data_len#赋值成员变量，方便后续调用
        self.udp_signal_write_msg.emit(msg)
        msg = "当前设置的采样频率:{}Hz\n".format(self.input_fs)
        self.udp_signal_write_msg.emit(msg)
        msg = "当前设置的OSR:{}\n".format(self.input_OSR)
        self.udp_signal_write_msg.emit(msg)
        msg = "当前设置的采样周期数:{}\n".format(self.input_fin)
        self.udp_signal_write_msg.emit(msg)
        msg = "计算可得输入信号频率fin=fs*M/N={}Hz\n".format(self.input_fin * self.input_fs / (self.data_byte / 4))
        self.udp_signal_write_msg.emit(msg)
    def udp_server_concurrency(self) -> None:
        """
        用于创建一个线程持续监听UDP通信
        """

        while True:
        #while self.plot_done_flag:
            time1 = time.perf_counter()  # 接收开始时间
            total_bytes_info = b''#最终65536字节的bytes数据
            total_info = '' #最终字符串
            self.num_cnt = 0#函数内部计数变量
            while self.num_cnt<self.data_byte:
                recv_msg, recv_addr = self.udp_socket.recvfrom(1024)
                if self.num_cnt == 0:
                    msg = f"来自IP:{recv_addr[0]}端口:{recv_addr[1]}:"
                    self.udp_signal_write_msg.emit(msg)  # 当前监听地址和端口号
                info = recv_msg.hex() #HEX解码
                bytes_info = bytes.fromhex(info)# 将字符串转换为hex格式bytes数据
                rx_num_once = len(bytes_info)  # 读取本次接收的数据长度（字节）
                self.num_cnt =self.num_cnt + rx_num_once
                total_bytes_info += bytes_info
                total_info += info
                #self.udp_signal_write_info.emit(info, self.InfoRec, rx_num_once)  # 接收到的str格式数据，接收到的字节数量
            self.udp_signal_len_info.emit(self.num_cnt)#发送总的接收到的字节数量给数据显示模块
            self.udp_save_str_info.emit(total_info)

            #将接收到的hex数据转换为int数据
            self.int_info = []
            for i in range(0, len(total_bytes_info), 4):
                four_bytes = total_bytes_info[i:i + 4]
                temp_int = struct.unpack('<I', bytes(four_bytes))[0]#小端数据格式解码
                self.int_info.append(temp_int)#数据转换成int格式

            #输出信息
            self.plot_signal_data_info.emit(self.int_info)#经过转换的int数据
            self.num_cnt = 0  # 清零计数
            time2 = time.perf_counter()  # 接收完成时间
            print("接收数据并初步处理耗时", time2 - time1)

    def udp_client_start(self, ip: str, port: int) -> None:
        """
        确认UDP客户端的ip及地址
        """
        self.udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.udp_socket.bind(("", 9000))  # 第一个参数是IP地址，空字符串表示使用默认的IP地址
        port = int(port)
        self.send_address = (ip, port)
        msg = "UDP客户端已启动\n"
        self.udp_signal_write_msg.emit(msg)

    def udp_send(self, send_info: str) -> None:
        """
        功能函数，用于UDP客户端发送消息
        """
        try:
            send_info_encoded = send_info.encode("utf-8")
            self.udp_socket.sendto(send_info_encoded, self.send_address)
            msg = "UDP客户端已发送"
            self.udp_signal_write_msg.emit(msg)
            self.udp_signal_write_info.emit(send_info, self.InfoSend,0)
        except Exception as ret:
            msg = "发送失败\n"
            self.udp_signal_write_msg.emit(msg)


    def udp_close(self) -> None:
        """
        功能函数，关闭网络连接的方法
        """
        if self.link_flag == self.ServerUDP:
            try:
                self.udp_socket.close()
                msg = "已断开网络\n"
                self.udp_signal_write_msg.emit(msg)
            except Exception as ret:
                pass

            try:
                StopThreading.stop_thread(self.sever_th)
            except Exception:
                pass


    NoLink = -1
    ServerUDP = 2
    ClientUDP = 3
    InfoSend = 0
    InfoRec = 1
