import time
import datetime
from PyQt5 import QtCore
from os import fstat

from PyQt5.QtCore import Qt, QTimer, pyqtSignal
from PyQt5.QtWidgets import QFileDialog, QMessageBox, QWidget, QMainWindow,QGridLayout

#user file
from Network import get_host_ip,get_board_ip
import MainWindowUI
from UI.MyWidgets import PortInputDialog#自定义widgets
#matplotlib
import matplotlib as mpl
mpl.use('Qt5Agg')# 声明使用pyqt5
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar
import matplotlib.pyplot as plt

#length_signal=0

class WidgetLogic(QMainWindow):
    link_signal = pyqtSignal(tuple)  # 连接类型, 目标IP, 本机/目标端口, 总长度（字节数）
    disconnect_signal = pyqtSignal()
    counter_signal = pyqtSignal(int,int)#rx计数，tx计数
    fft_signal = pyqtSignal(str,str,str)
    send_signal = pyqtSignal(str)
    rx_num_signal = pyqtSignal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        #变量定义
        self.SendCounter = 0
        self.file_name = None
        self.udp_per_rx = None
        self.figtoolbar1 = None
        self.canvas1 = None
        self.fig1 = None
        self.figtoolbar2 = None
        self.canvas2 = None
        self.fig2 = None
        self.protocol_type = "UDP"  #连接类型
        self.link_flag = self.NoLink #连接状态flag
        self.receive_show_flag = True  # 是否显示接收到的消息
        self.ReceiveCounter = 0 #接收数据计数
        self.dir = None

        #MainwindowUI
        self.__ui = MainWindowUI.Ui_MainWindow()
        self.__ui.setupUi(self)
        self.__ui.retranslateUi(self)

        #输入框初始值设定
        #self.setWindowFlags(Qt.WindowStaysOnTopHint)  # 保持窗口最前
        self.__ui.MyHostAddrLineEdit.setText(get_host_ip())  # 显示本机IP地址
        #self.__ui.MyPortLineEdit.setText(str(8000))  # 默认端口为8000
        self.__ui.RxPointLineEdit.setText(str(65536)) # 默认点数为65536
        self.__ui.fsLineEdit.setText(str(31250))  # 默认采样频率32000
        self.__ui.OSRLineEdit.setText(str(32))  # 默认过采样率32
        self.__ui.finLineEdit.setText(str(31))  # 默认采样周期数31

        #信号触发与槽函数连接
        self.counter_signal.connect(self.counter_signal_handler)#将counter signal信号连接到counter_signal_handler槽函数
        self.__ui.pushButton_IP.clicked.connect(self.set_board_ip)
        self.__ui.SaveButton.clicked.connect(self.save_data_init)
        self.__ui.ConnectButton.toggled.connect(self.connect_button_toggled_handler)#将连接按钮按住动作连接到connect_button_toggled_handler槽函数
        self.__ui.SendButton.clicked.connect(self.send_link_handler)#将发送按钮按住动作连接到send_link_handler槽函数
        self.__ui.CounterResetLabel.clicked.connect(self.counter_reset_button_handler)#将复位计数按钮点击动作连接到counter_reset_button_handler槽函数
        self.__ui.ReceivePauseCheckBox.toggled.connect(
            self.receive_pause_checkbox_toggled_handler
        )#将暂停接收显示按钮按住动作连接到receive_pause_checkbox_toggled_handler槽函数
        self.fft_signal.connect(self.fft_signal_handler)#将接收到的fft结果连接到fft_signal_handler，在UI上显示
        self.rx_num_signal.connect(self.rx_num_signal_handler)#画图之前进行接收数据长度检查
        #绘画界面UI初始化
        self.plot_ui()

    def connect_button_toggled_handler(self, state):
        if state:
            # 连接按钮连接
            self.click_link_handler()
        else:
            # 连接按钮断开连接
            self.click_disconnect()
            self.editable(True)

    def editable(self, able: bool = True):
        """当连接建立后，部分选项不可再修改"""
        self.__ui.MyPortLineEdit.setReadOnly(not able)
        self.__ui.MyHostAddrLineEdit.setReadOnly(not able)
        self.__ui.RxPointLineEdit.setReadOnly(not able)
        self.__ui.TargetIPLineEdit.setReadOnly(not able)
        self.__ui.TargetPortLineEdit.setReadOnly(not able)
        self.__ui.SendPlainTextEdit.setEnabled(True)


    def click_link_handler(self):
        """连接按钮连接时的槽函数"""
        server_flag = False  # Server/Client模式标识符
        my_ip = str(self.__ui.MyHostAddrLineEdit.text())
        target_ip = str(self.__ui.TargetIPLineEdit.text())
        def get_int_data(port):
            # 用户未输入端口则置为-1
            return -1 if port == "" else int(port)
        my_port = get_int_data(self.__ui.MyPortLineEdit.text())#获取UI端MyPortLineEdit中输入的端口号
        target_port = get_int_data(self.__ui.TargetPortLineEdit.text())
        max_length = get_int_data(self.__ui.RxPointLineEdit.text())#获取UI端RxPointLineEdit中输入的采样字节数
        fs= get_int_data(self.__ui.fsLineEdit.text())#获取UI端fsLineEdit中输入
        osr= get_int_data(self.__ui.OSRLineEdit.text())#获取UI端OSRLineEdit中输入
        fin= get_int_data(self.__ui.finLineEdit.text())#获取UI端finLineEdit中输入
        self.editable(False)  # 建立连接后不可再修改参数

        if  (my_port==-1 and target_port==-1 and target_ip=="") or max_length==-1 or fs==-1 or osr==-1 or fin==-1:
            mb = QMessageBox(QMessageBox.Critical, "错误", "请输入信息", QMessageBox.Ok, self)
            mb.open()#若没有输入完整信息，弹出错误消息提示
            self.editable(True)
            self.__ui.ConnectButton.setChecked(False)
            return None
        elif my_port != -1 and target_port != -1 and target_ip != "":
            mb = QMessageBox(
                QMessageBox.Critical, "警告", "请勿同时输入本地与目标信息", QMessageBox.Ok, self
            )
            mb.open()#如果同时输入了本地端口和目标端口和IP，无法确定作为服务端还是客户端
            self.editable(True)
            self.__ui.ConnectButton.setChecked(False)
            return None
        elif target_port == -1 and target_ip == "":
            server_flag = True#如果未输入目标端口和IP，作为Server端
        elif target_port == -1 and target_ip != "":
            input_d = PortInputDialog(self)
            input_d.setWindowTitle("连接失败")
            input_d.setLabelText("请输入目标端口号作为Client启动，或取消")
            input_d.intValueSelected.connect(
                lambda val: self.__ui.TargetPortLineEdit.setText(str(val))
            )
            input_d.open()
            self.__ui.ConnectButton.setChecked(False)
            # 提前终止槽函数
            return None
        elif target_port != -1 and target_ip == "":
            mb = QMessageBox(
                QMessageBox.Critical, "Client启动错误", "请输入目标IP地址", QMessageBox.Ok, self
            )
            mb.open()
            self.__ui.ConnectButton.setChecked(False)
            # 提前终止槽函数
            return None

        if self.file_name is None:
            mb = QMessageBox(QMessageBox.Critical, "错误", "请确定数据保存地址", QMessageBox.Ok, self)
            mb.open()#若没有输入完整信息，弹出错误消息提示
            self.editable(True)
            self.__ui.ConnectButton.setChecked(False)
            return None

        if max_length < fs * 2:
            mb = QMessageBox(QMessageBox.Critical, "警告", "为防止程序崩溃，接收字节数需大于采样频率的两倍", QMessageBox.Ok, self)
            mb.open()#若没有输入完整信息，弹出错误消息提示
            self.editable(True)
            self.__ui.ConnectButton.setChecked(False)
            return None

        if self.protocol_type == "UDP" and server_flag:#udp服务端
            self.link_signal.emit((self.ServerUDP, my_ip, my_port,max_length,fs,osr,fin))
            self.link_flag = self.ServerUDP
            #self.__ui.StateLabel.setText(str(max_length))#用来确定正确读取到了采样点数
            self.__ui.StateLabel.setText('UDP服务端')
        elif self.protocol_type == "UDP" and not server_flag:#udp客户端
            self.link_signal.emit((self.ClientUDP, target_ip, target_port,"","","",""))
            self.link_flag = self.ClientUDP
            self.__ui.StateLabel.setText("UDP客户端")

    def send_link_handler(self):
        """
        SendButton控件点击触发的槽
        """
        if self.link_flag != self.NoLink:
            send_msg = self.__ui.SendPlainTextEdit.toPlainText()
            self.send_signal.emit(send_msg)



    def msg_write(self, msg: str):
        """将提示消息写入ReceivePlainTextEdit"""
        if self.receive_show_flag:
            self.__ui.ReceivePlainTextEdit.appendPlainText(msg)

    def info_write(self, info: str, mode: int,rx_num: int):#receive counter计数
        """
        将接收到或已发送的消息写入ReceivePlainTextEdit
        :param rx_num: 接收到的数据量（字节数）
        :param info: 接收或发送的消息
        :param mode: 模式，接收/发送
        :return: None
        """
        if self.receive_show_flag:
            if mode == self.InfoRec:
                self.__ui.ReceivePlainTextEdit.appendHtml(
                    f'<font color="blue">{info}</font>'
                )
                self.ReceiveCounter += rx_num
                self.counter_signal.emit(self.ReceiveCounter,self.SendCounter)
            elif mode == self.InfoSend:
                self.__ui.ReceivePlainTextEdit.appendHtml(
                    f'<font color="green">{info}</font>'
                )
            self.__ui.ReceivePlainTextEdit.appendHtml("\n")
        else:
            if mode == self.InfoRec:
                self.ReceiveCounter += rx_num
                self.counter_signal.emit(self.ReceiveCounter,self.SendCounter)

        self.udp_per_rx = rx_num

    def len_write(self, rx_num: int):#receive counter计数
        self.ReceiveCounter += rx_num
        self.counter_signal.emit(self.ReceiveCounter,self.SendCounter)
        self.udp_per_rx = rx_num

    def click_disconnect(self):
        self.disconnect_signal.emit()
        self.link_flag = self.NoLink
        self.__ui.StateLabel.setText("未连接")

    def counter_signal_handler(self, receive_count,send_count):
        """控制接收计数器显示变化的槽函数"""
        self.__ui.ReceiveCounterLabel.setText(str(receive_count))#将接收ReceiveCounterLabel的值设置为receive_count
        self.__ui.SendCounterLabel.setText(str(send_count))

    def counter_reset_button_handler(self):#将ReceiveCounter设置为0
        """清零计数器的槽函数"""
        self.ReceiveCounter = 0
        self.SendCounter = 0
        self.counter_signal.emit(self.ReceiveCounter,self.SendCounter)


    def receive_pause_checkbox_toggled_handler(self, ste: bool):
        """暂停接受复选框的槽函数"""
        if ste:
            self.receive_show_flag = False
        else:
            self.receive_show_flag = True

    def plot_ui(self):
        #绘画数据
        self.fig1 = plt.figure()  # 创建figure对象
        self.canvas1 = FigureCanvas(self.fig1)  # 创建figure画布
        self.figtoolbar1 = NavigationToolbar(self.canvas1, self)  # 创建figure工具栏
        self.fig2 = plt.figure()  # 创建figure对象
        self.canvas2 = FigureCanvas(self.fig2)  # 创建figure画布
        self.figtoolbar2 = NavigationToolbar(self.canvas2, self)  # 创建figure工具栏
        #布局
        self.gridlayout1 = QGridLayout(self.__ui.groupBox1)  # 继承容器groupBox
        self.gridlayout1.addWidget(self.canvas1)  # 画布添加到窗口布局中
        self.gridlayout1.addWidget(self.figtoolbar1)  # 工具栏添加到窗口布局中
        self.gridlayout2 = QGridLayout(self.__ui.groupBox2)  # 继承容器groupBox
        self.gridlayout2.addWidget(self.canvas2)  # 画布添加到窗口布局中
        self.gridlayout2.addWidget(self.figtoolbar2)  # 工具栏添加到窗口布局中

    def set_board_ip(self):
        self.__ui.MyHostAddrLineEdit.setText(get_board_ip())  # 显示本机IP地址

    def fft_signal_handler(self, sndr_result,enob_result,max_result):
        """控制接收计数器显示变化的槽函数"""
        self.__ui.SNDRLabel.setText(str(sndr_result))#将SNDRLabel的值设置为SNDR
        self.__ui.enoblabel.setText(str(enob_result))#将SNDRLabel的值设置为SNDR
        self.__ui.maxlabel.setText(str(max_result))

    def rx_num_signal_handler(self,num):
        if self.data_dot != num:#如果用户端输入的字节数与接收端接收的字节数不同，报错
            mb = QMessageBox(QMessageBox.Critical, "错误", "请输入正确的接收数据长度（字节）", QMessageBox.Ok, self)
            mb.open()  # 若没有输入完整信息，弹出错误消息提示
            self.editable(True)
            self.__ui.ConnectButton.setChecked(False)
            return None

    def save_data_init(self):
        self.file_name = QFileDialog.getSaveFileName(self, "保存到txt", "./data.txt", "ALL(*, *);;txt文件(*.txt)", "txt文件(*.txt)")[0]#开启保存文件窗口

    def save_data(self,str_data):
        time.sleep(0.1)#暂停，给函数留出计算sndr的时间,时长根据输出结果自己调整
        print(self.savedata_flag)
        time.sleep(0.1)  # 暂停，给函数留出计算sndr的时间
        print(self.savedata_flag)
        if self.savedata_flag==1:
            try:
                with open(self.file_name, mode="a") as f:
                    #str_data='test_str_info'
                    now = datetime.datetime.now()
                    time_str = now.strftime("%Y-%m-%d %H:%M:%S")
                    f.write(time_str)
                    f.write('\r\n')
                    f.write('start of saving data\n')
                    f.write('new high sndr:')
                    f.write(str(self.maxSNDR))
                    f.write('\r\n')
                    f.write('here is data str\n')
                    f.write(str_data)
                    f.write('\r\n')
                    f.write('end of saving data\n')
                    self.savedata_flag = 0
            except FileNotFoundError:
                pass  # 如果用户取消输入，filename为空，会出现FileNotFoundError

    NoLink = -1
    ServerUDP = 2
    ClientUDP = 3


    #print("当前len值为%d" % length_signal)
if __name__ == "__main__":
    import sys
    from PyQt5.QtWidgets import QApplication

    #QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling)#高分辨率适应

    app = QApplication(sys.argv)
    window = WidgetLogic()
    window.show()
    sys.exit(app.exec_())
