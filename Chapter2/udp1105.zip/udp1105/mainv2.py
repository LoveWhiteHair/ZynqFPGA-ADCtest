import math
from signal import signal

from PyQt5.QtWidgets import QApplication,QGridLayout
from PyQt5 import QtCore
import socket
import sys
#user file
import MainWindowUI
from mainwindowlogic import *#UI界面逻辑功能和len_signal全局变量
from Network import NetworkLogic #Network库，内部定义了UDP逻辑
#画图
import numpy as np
import matplotlib.pyplot as plt
import struct
import scipy.signal
import time
from UI.MyWidgets import MyFigure



class MainWindow(WidgetLogic, NetworkLogic):
    def __init__(self, parent=None):
        super().__init__(parent)
        #检测屏幕分辨率
        self.desktop = QApplication.desktop()
        self.screenRect = self.desktop.screenGeometry()
        self.screenheight = self.screenRect.height()
        self.screenwidth = self.screenRect.width()
        self.height = int(self.screenheight * 0.7)
        self.width = int(self.screenwidth * 0.7)
        print("Screen height {}".format(self.screenheight))
        print("Screen width {}".format(self.screenwidth))
        self.resize(self.width, self.height)



        self.savedata_flag = None
        self.maxSNDR = 0
        self.enob = None
        self.SNDR = None
        self.input_fin = None
        self.input_OSR = None
        self.input_fs = None
        self.step = 0


        self.link_signal.connect(self.link_signal_handler)#连接至udp服务器
        self.disconnect_signal.connect(self.disconnect_signal_handler)#关闭连接
        self.send_signal.connect(self.send_signal_handler)#数据发送模块
        self.udp_signal_write_msg.connect(self.msg_write)#udp连接信息显示
        self.udp_signal_write_info.connect(self.info_write)#udp接收数据显示
        self.udp_signal_len_info.connect(self.len_write)#udp接收长度label显示
        self.udp_save_str_info.connect(self.save_data)#数据保存函数
        self.plot_signal_data_info.connect(self.data_plot)#接收画图数据被触发后进行画图函数



    def link_signal_handler(self, signal) -> None:
        """
        启动UDP server连接
        """
        link_type, ip, port,data_len,self.input_fs,self.input_OSR,self.input_fin = signal
        if link_type == self.ServerUDP:
            self.udp_server_start(ip,port,data_len)
        elif link_type == self.ClientUDP:
            self.udp_client_start(ip, port)

    def disconnect_signal_handler(self) -> None:
        """关闭UDP server连接"""
        if self.link_flag == self.ServerUDP:
            self.udp_close()

    def send_signal_handler(self, msg: str) -> None:
        """发送按钮的槽函数"""
        if self.link_flag == self.ClientUDP:
            self.udp_send(msg)
            self.SendCounter = self.SendCounter+1
        self.counter_signal.emit(self.ReceiveCounter,self.SendCounter)

    def closeEvent(self, event) -> None:
        """
        重写closeEvent方法，实现MainWindow窗体关闭时执行一些代码
        :param event: close()触发的事件
        """
        self.disconnect_signal_handler()




    def data_plot(self):

        #print(f'int_info = {self.int_info}')#debug代码，确认正确接收到了数据
        #对int数组归一化到-1和1之间（fft函数需要幅值为1的数据），调用画图函数进行画图
        plot_data = self.int_info#接收到的16384个int数据
        data_dot = int(self.data_byte/4)#接收到的数据量为65536/4=16384个数
        #print(f'plot_data = {plot_data}')#debug代码，确认正确接收到了数据
        #print(type(plot_data))
        #print(len(plot_data))
        min_value=min(plot_data,default=None)
        print(f'min_value = {min_value}')
        max_value=max(plot_data,default=None)
        print(f'max_value = {max_value}')
        ysig = plot_data
        ysig = np.array(ysig)
        ysig = np.resize(ysig, (data_dot,)) # 形状变为 (16384,)#此语句很重要，因为一开始运行会有几个空数组，造成数组长度不同报错
        print(f"转换为numpy数组后list的形状：{ysig.shape}")
        print(ysig)
        print(len(ysig))
        print(type(ysig))


        #ynoise = 0.1 * np.random.randn(data_dot)
        #ydata = ysig + ynoise
        ydata = ysig
        self.calc_snr2(ydata, data_dot, self.input_fs, self.input_OSR, self.input_fin, 0)



    def calc_snr2(self, origin_data, nfft, fs, osr, fin_m, sig_mode):#原始数据，fft点数，采样频率，osr，采样周期数M，运行形式
        time1 = time.perf_counter()#fft函数开始时间
        sample=int(nfft)
        v_full_scale = 2048
        sample_list=np.linspace(1,sample,sample)#1-65536
        sample_list2=np.linspace(0,sample-1,sample)#0-65535
        win = 0.5*(1 - np.cos(2*np.pi*sample_list2/sample))#加窗为Hanning窗
        get_data = origin_data[-nfft:]
        get_data = get_data - np.mean(get_data)#均值降为0
        fin=fin_m / nfft * fs#输入信号频率
        f_norm=fin/fs #归一化的输入信号频率
        fb=nfft / 2 / osr #基带信号点数
        nsig = 3
        if sig_mode==0:#常规信号模式
            # signal=(sample/sum(w))*sinusx(yy1.*w,f,sample)
            # 提取信号中的正弦成分
            yy1=get_data
            yy1_fil = get_data * win
            sinx=np.sin(2*np.pi*f_norm*sample_list)
            cosx=np.cos(2*np.pi*f_norm*sample_list)
            a1=2*sinx*yy1_fil
            a=sum(a1)/sample
            b1=2*cosx*yy1_fil
            b=sum(b1)/sample
            signal=a*sinx + b*cosx
            signal=(sample/sum(win))*signal
            noise=get_data-signal
            # 计算输入信号，signal，noise的功率值
            stot = np.square(abs(np.fft.fft((yy1 * win))))  # Bitstream PSD
            ssignal = np.square(abs(np.fft.fft((signal * win))))  # Signal PSD
            snoise = np.square(abs(np.fft.fft((noise * win))))  # Noise PSD
            # 计算总功率
            pwsignal = sum(ssignal[nsig - 1:int(fb)])  # Signal power
            pwnoise = sum(snoise[nsig - 1:int(fb)])  # Noise power
            # 各输出值
            # snrdB:SNR in dB
            snr = pwsignal / pwnoise
            snrdB = 10 * np.log10(snr)
            enob = (snrdB - 1.76) / 6.02
            # ptotdB:Sigma-Delta modulator output power spectral density (vector) in dB
            temp1 = sum(stot[0:int(sample / 2)])
            temp2 = yy1[0:sample]
            temp2 = temp2.astype(np.int32)
            temp3 = np.square(temp2)
            temp4 = sum(np.zeros(1))  # 首先用一个0求和强制temp4为64位变量，否则后面会超界
            for i in range(0, sample):  # 此处sum(temp3)会把temp4转换为32位变量（why），因此使用for求和
                temp4 = temp4 + temp3[i]
            norm = temp1 / temp4 * sample  # PSD normalization
            # norm=sum(stot(1:sample/2))/sum(yy1(1:sample).^2)*sample;
            ptot = stot / norm
            ptotdB = 10 * np.log10(ptot)
            ptotdB = ptotdB[0:int(sample / 2)]
            vpp_in = max(signal)
            dB_add = -20 * np.log10(np.abs(vpp_in) / v_full_scale)
            ptotdB_norm = ptotdB - max(ptotdB) - dB_add
        if sig_mode==1:
            yy1 = get_data#real noise signal
            signal = 2048 * np.sin(2 * np.pi * f_norm * sample_list)
            noise = 1 * yy1
            yy2 = signal + noise#noise with FS signal
            # 计算输入信号，signal，noise的功率值
            stot = np.square(abs(np.fft.fft((yy1 * win))))  # Plot PSD
            stot2 = np.square(abs(np.fft.fft((yy2 * win))))  # Calculated PSD
            ssignal = np.square(abs(np.fft.fft((signal * win))))  # Signal PSD
            snoise = np.square(abs(np.fft.fft((noise * win))))  # Noise PSD
            # 计算总功率
            pwsignal = sum(ssignal[nsig - 1:int(fb)])  # Signal power
            pwnoise = sum(snoise[nsig - 1:int(fb)])  # Noise power
            # 各输出值
            # snrdB:SNR in dB
            snr = pwsignal / pwnoise
            snrdB = 10 * np.log10(snr)
            enob = (snrdB - 1.76) / 6.02
            # ptotdB:Sigma-Delta modulator output power spectral density (vector) in dB
            temp1 = sum(stot[0:int(sample / 2)])
            temp2 = yy1[0:sample]
            temp2 = temp2.astype(np.int32)
            temp3 = np.square(temp2)
            temp4 = sum(np.zeros(1))  # 首先用一个0求和强制temp4为64位变量，否则后面会超界
            for i in range(0, sample):  # 此处sum(temp3)会把temp4转换为32位变量（why），因此使用for求和
                temp4 = temp4 + temp3[i]
            norm = temp1 / temp4 * sample  # PSD normalization

            temp1_2 = sum(stot2[0:int(sample / 2)])
            temp2_2 = yy2[0:sample]
            temp2_2 = temp2_2.astype(np.int32)
            temp3_2 = np.square(temp2_2)
            temp4_2 = sum(np.zeros(1))  # 首先用一个0求和强制temp4为64位变量，否则后面会超界
            for i in range(0, sample):  # 此处sum(temp3)会把temp4转换为32位变量（why），因此使用for求和
                temp4_2 = temp4_2 + temp3_2[i]
            norm2 = temp1_2 / temp4_2 * sample  # PSD normalization

            # norm=sum(stot(1:sample/2))/sum(yy1(1:sample).^2)*sample;
            ptot = stot / norm # Plot PSD
            ptot2 = stot2 / norm2 # Calculated PSD
            ptotdB = 10 * np.log10(ptot)
            ptotdB2 = 10 * np.log10(ptot2)
            ptotdB = ptotdB[0:int(sample / 2)]
            ptotdB2 = ptotdB2[0:int(sample / 2)]
            ptotdB_norm = ptotdB - max(ptotdB2)
        #输出值
        self.SNDR=snrdB
        if self.SNDR > self.maxSNDR and not math.isinf(self.SNDR):#出现新的最大值且不为无穷时（避免空数组时的log(0))
            self.maxSNDR = self.SNDR
            self.savedata_flag = 1#设置需要保存本次数据
        self.enob=enob
        time2 = time.perf_counter()#fft完成时间



        # Graphs
        time3 = time.perf_counter()#画图函数开始时间
        if True:  # enable plot
            self.step+=1
            x_label = np.arange(0, fs / 2, fs / nfft)
            # 数据图
            self.fig1.clf()#清理画布
            ax1 = self.fig1.subplots
            ax1.cla()  # 清除绘图区
            #ax1.plot(np.arange(nfft), data)
            ax1.plot(np.arange(nfft), get_data*1.8/2048)
            ax1.set_title('data PLOT')
            ax1.set_ylabel('Voltage(V)')
            ax1.minorticks_on()  # 坐标轴小刻度
            ax1.grid(which='minor', axis='both')#开启网格
            self.fig1.canvas.draw()  # 这里注意是画布重绘，self.figs.canvas
            self.fig1.canvas.flush_events()  # 画布刷新self.figs.canvas
            # fft频谱图
            self.fig2.clf()#清理画布
            ax2 = self.fig2.subplots()
            ax2.cla()  # 清除绘图区
            #ax2.plot(x_label, 10 * np.log10(np.abs(ptot)))
            ax2.plot(x_label, ptotdB_norm)
            ax2.set_xscale("log")
            ax2.set_title('PSD PLOT')
            ax2.set_ylabel('AMPLITUDE(dBFS)')
            ax2.minorticks_on()  # 坐标轴小刻度
            ax2.set_ylim((-160, 10))
            ax2.grid(which='both', axis='both')#开启网格
            self.fig2.canvas.draw()  # 这里注意是画布重绘，self.figs.canvas
            self.fig2.canvas.flush_events()  # 画布刷新self.figs.canvas
            #画图完成提示句—
            print(f'plot ax1 and ax2 finished,step={self.step}')
        #输出fft计算结果
        self.fft_signal.emit(str(self.SNDR),str(self.enob),str(self.maxSNDR))
        time4 = time.perf_counter()#画图完成时间
        print("fft运行耗时", time2 - time1)
        print("画图运行耗时", time4 - time3)
        print("本轮运行结束，这里是分隔符")








if __name__ == '__main__':
    QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling)#高分辨率适应
    app = QApplication(sys.argv)  # 在 QApplication 方法中使用，创建应用程序对象
    myWin = MainWindow()  # 实例化 MyMainWindow 类，创建主窗口
    myWin.show()  # 在桌面显示控件 myWin
    sys.exit(app.exec_())  # 结束进程，退出程序