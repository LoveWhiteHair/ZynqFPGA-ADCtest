year_fund=20
sum_fund=0
print(f'第1年工资结余{year_fund}')
for i in range (10):
    sum_fund = sum_fund + year_fund
    sum_fund = sum_fund * 1.1
    print(f'第{i+1}年存款{sum_fund}')
    year_fund = year_fund * 1.1
    print(f'第{i+2}年工资结余{year_fund}')
