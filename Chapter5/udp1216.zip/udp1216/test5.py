import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import time
from scipy.interpolate import interp1d
import numpy as np

# 所有坐标点
index_row1 = [(50,22),(62,22),(74,22),(86,22)]
index_row2 = [(50,34),(62,34),(74,34),(86,34)]
index_row3 = [(50,46),(62,46),(74,46),(86,46)]
index_row4 = [(50,58),(62,58),(74,58),(86,58)]
index_row5 = [(27,156),(39,156),(51,156),(63,156),(75,156),(87,156),(99,156),(111,156)]
index_row6 = [(25,171),(37,171),(49,171),(61,171),(73,171),(85,171),(97,171),(109,171)]
index_row7 = [(22,186),(34,186),(46,186),(58,186),(70,186),(82,186),(94,186),(106,186)]
index_row8 = [(22,201),(34,201),(46,201),(58,201),(70,201),(82,201),(94,201),(106,201)]
index_row9 = [(27,216),(39,216),(51,216),(63,216),(75,216),(87,216),(99,216)]
index_row10 = [(34,231),(46,231),(58,231),(70,231),(82,231)]
index_row11 = [(45,246),(57,246)]

# 合并所有坐标
index_row = (index_row1 + index_row2 + index_row3 + index_row4 + index_row5 + index_row6
             + index_row7 + index_row8 + index_row9 + index_row10 + index_row11)

# 新添加的坐标点（已修正错误）
new_points = [
    (37.3,103.5), (37.5,102.5), (38.3,98.7), (39.6,83.4), (38.0,62.7),
    (33.7,41.8), (37.3,29.6), (38.6,21.7), (42.3,16.1), (46.9,9.4),
    (57.5,4.1), (68.6,3.2), (73.2,3.3), (79.4,3.8), (85.5,4.2),
    (94,8), (99.6,17.2), (108,29.6), (110.5,48.1), (110.1,68.6),
    (110.4,84.7), (109.9,99.9), (113.3,112.6), (118.7,130.6), (121.2,148.6),
    (121.3,169), (121.2,185.1), (119.6,200.0), (114.4,213.5), (108.1,228.9),
    (98.6,246.2), (84.1,259.3), (64.8,264.2), (47.8,261.0), (35.2,252.3),
    (23.4,240.2), (19.5,217.2), (13.2,187.8), (19.3,163.4), (22.6,142.4),
    (28.7,130.9), (32.8,121.5), (34.2,117)
]

# 创建绘图
fig, ax = plt.subplots(figsize=(5, 10.6))

# 设置坐标轴的范围
ax.set_xlim(0, 125)
ax.set_ylim(0, 265)

# 开始计时
start_time = time.time()

# 绘制小方格
for x, y in index_row:
    # 创建一个 1x1 的矩形（左下角坐标 (x, y)）
    rect = Rectangle((x, y), 6, 6, linewidth=1, edgecolor='red', facecolor='blue', alpha=0.3)
    ax.add_patch(rect)

# 绘制新添加的点
x_coords, y_coords = zip(*new_points)
ax.scatter(x_coords, y_coords, color='black', s=20, zorder=5)

# 使用插值生成更平滑的曲线
num_interpolation_points = 1000  # 插值点的数量
t = np.linspace(0, 1, len(x_coords))
t_interp = np.linspace(0, 1, num_interpolation_points)
x_interp = interp1d(t, x_coords, kind='quadratic')(t_interp)
y_interp = interp1d(t, y_coords, kind='quadratic')(t_interp)

# 用黑色平滑曲线连接这些点
ax.plot(x_interp, y_interp, color='black', linewidth=1, linestyle='-', zorder=4)

# 结束计时
end_time = time.time()
total_time = end_time - start_time
print(f"绘制整张图的时间: {total_time:.4f} 秒")

plt.show()