


import decimal

#N = decimal.Decimal('256')
#fs = decimal.Decimal('400000')
N=256
fs=400000/20
b=13.16e-3
a=b-N/fs
temp=5*1.8/32
print(a)
print(temp)

