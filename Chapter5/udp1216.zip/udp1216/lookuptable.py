def find_byte_in_lookup_table(target_byte, lookup_table):
    """
    查找2字节数据在查找表中的位置

    参数:
    target_byte -- 要查找的2字节数据，可以是整数或者字节序列
    lookup_table -- 查找表，应该是一个由两个相邻字节组成的列表或字节序列

    返回:
    如果找到匹配，返回起始位置；否则返回-1
    """
    # 确保查找表是字节序列，如果是列表则转换
    if isinstance(lookup_table, list):
        lookup_table = bytes(lookup_table)

    # 如果目标是整数，确保它是一个2字节值
    if isinstance(target_byte, int):
        if 0 <= target_byte <= 0xFFFF:
            target_byte = target_byte.to_bytes(2, byteorder='little')
        else:
            raise ValueError("目标整数必须在0到65535之间")

    # 遍历查找表
    for i in range(len(lookup_table) - 1):
        if lookup_table[i] == target_byte[0] and lookup_table[i + 1] == target_byte[1]:
            return i  # 返回起始位置

    return -1  # 未找到


# 示例使用
if __name__ == "__main__":
    # 示例查找表 - 可以是任意2字节序列
    lookup_table = [
        0xA1, 0xB2, 0xC3, 0xD4, 0xE5, 0xF6,
        0x98, 0x7A, 0x5B, 0x3C, 0x1D, 0x0E
    ]

    # 目标2字节数据
    target_byte = bytes([0x7A, 0x98])  # 可以直接使用字节序列
    # 或者使用整数: target_byte = 0x987A

    position = find_byte_in_lookup_table(target_byte, lookup_table)

    if position >= 0:
        print(f"找到目标数据在查找表中的位置: 第 {position} 位")
    else:
        print("目标数据未在查找表中找到")