from .Udp import UdpLogic, get_host_ip, get_board_ip



class NetworkLogic(UdpLogic):
    """
    综合了 UDP  的类
    """
    pass