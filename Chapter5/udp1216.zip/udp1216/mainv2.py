import matplotlib.patches as patches
from mpl_toolkits.axes_grid1 import make_axes_locatable
from PyQt5.QtWidgets import QApplication,QGridLayout
from PyQt5 import QtCore
import threading
import random
import socket
import sys
import MainWindowUI

#user file
from mainwindowlogic import *#UI界面逻辑功能和len_signal全局变量
from Network import NetworkLogic #Network库，内部定义了UDP逻辑
#画图
import time


class MainWindow(WidgetLogic, NetworkLogic):
    def __init__(self, parent=None):
        super().__init__(parent)
        #检测屏幕分辨率
        self.desktop = QApplication.desktop()
        self.screenRect = self.desktop.screenGeometry()
        self.screenheight = self.screenRect.height()
        self.screenwidth = self.screenRect.width()
        self.height = int(self.screenheight * 0.7)
        self.width = int(self.screenwidth * 0.45)
        print("Screen height {}".format(self.screenheight))
        print("Screen width {}".format(self.screenwidth))
        self.resize(self.width, self.height)



        self.time_step = 0
        self.step = 0
        self.plot_flag=1


        self.link_signal.connect(self.link_signal_handler)#连接至udp服务器
        self.disconnect_signal.connect(self.disconnect_signal_handler)#关闭连接
        self.send_signal.connect(self.send_signal_handler)#数据发送模块
        self.udp_signal_write_msg.connect(self.msg_write)#udp连接信息显示
        self.udp_signal_write_info.connect(self.info_write)#udp接收数据显示
        self.udp_signal_len_info.connect(self.len_write)#udp接收长度label显示
        #self.plot_signal_data_info.connect(self.on_plot_signal_data_info)#接收画图数据被触发后传入画图线程，进行绘图
        self.plot_signal_data_info.connect(self.data_process)  # 接收画图数据被触发后传入画图函数，进行绘图

        #初始化固定的画图坐标
        #小格子们的坐标
        index_row1 = [(50, 22), (62, 22), (74, 22), (86, 22)]
        index_row2 = [(50, 34), (62, 34), (74, 34), (86, 34)]
        index_row3 = [(50, 46), (62, 46), (74, 46), (86, 46)]
        index_row4 = [(50, 58), (62, 58), (74, 58), (86, 58)]
        index_row5 = [(27, 156), (39, 156), (51, 156), (63, 156), (75, 156), (87, 156), (99, 156), (111, 156)]
        index_row6 = [(25, 171), (37, 171), (49, 171), (61, 171), (73, 171), (85, 171), (97, 171), (109, 171)]
        index_row7 = [(22, 186), (34, 186), (46, 186), (58, 186), (70, 186), (82, 186), (94, 186), (106, 186)]
        index_row8 = [(22, 201), (34, 201), (46, 201), (58, 201), (70, 201), (82, 201), (94, 201), (106, 201)]
        index_row9 = [(27, 216), (39, 216), (51, 216), (63, 216), (75, 216), (87, 216), (99, 216)]
        index_row10 = [(34, 231), (46, 231), (58, 231), (70, 231), (82, 231)]
        index_row11 = [(45, 246), (57, 246)]
        self.index_row = (index_row1 + index_row2 + index_row3 + index_row4 + index_row5 + index_row6
                     + index_row7 + index_row8 + index_row9 + index_row10 + index_row11)
        #鞋子轮廓的坐标
        self.new_points = [
            (37.3, 103.5), (37.5, 102.5), (38.3, 98.7), (38.8, 91.4), (38.9, 83.4), (38.8, 77.3), (37.4, 62.7),
            (35.6, 50.2)
            , (34.9, 41.8), (35.5, 36.8), (37.0, 29.6), (38.8, 21.7), (42.3, 16.1), (46.5, 10.9), (51.3, 7.7),
            (57.5, 5.2), (62.9, 4.1), (68.6, 3.2), (73.2, 3.3), (79.4, 3.8), (82.9, 4.0),
            (85.5, 4.6), (89.6, 6.3), (93.2, 9), (99.6, 17.2), (104, 24.3), (106.6, 29.7),
            (109, 38.7), (109.9, 48.1), (109.9, 68.6), (110.4, 84.7), (110.2, 91.8), (110.6, 99.9), (113.3, 112.6),
            (116.9, 125), (119.7, 137.5), (120.2, 140.7), (121.2, 148.6), (121.5, 169), (121.2, 185.1),
            (120.4, 192.8), (119.8, 196.3), (119, 200.4), (117, 206.7),
            (114.4, 213.5), (111.3, 221), (107.8, 228.7), (105.7, 232.9), (102.4, 239), (97.4, 245.8), (93.5, 250.1),
            (89.3, 254.1), (81.9, 258.7),
            (76, 261.1), (68.3, 262.6), (64.8, 262.8), (59.6, 262.5), (55.5, 262), (49.4, 260.2),
            (42.3, 256.9), (38.8, 254.6), (31.8, 248.7), (27.1, 242.9), (25.2, 239.8),
            (22.8, 233.4), (21.2, 227.1), (19.3, 217.2),
            (17, 204.7), (16.3, 200), (15.7, 193.3),
            (15.6, 190.6), (15.9, 184.9), (16.2, 179.7), (18, 167.6), (20, 158),
            (22, 148.1), (23.1, 143.3), (24.4, 140.1), (26.3, 136),
            (28.7, 130.9), (32.8, 121.5), (34.2, 117),
            (37.3, 103.5)
        ]
        # 用于控制线程运行状态
        self.running = True
        # 用于存储待处理的数据
        self.pending_data = []
        self.data_lock = threading.Lock()  # 用于线程安全
############################启用主线程画图时记得注释掉#############################################

        # 启动一个子线程用于处理 data_process
        self.data_process_thread = threading.Thread(target=self.data_process_thread_loop)
        self.data_process_thread.daemon = True  # 设置为守护线程
        self.data_process_thread.start()


############################bebug测试代码，记得注释掉#############################################

        # 启动一个子线程用于定时生成数据并调用 plot_signal_data_info.emit
        self.thread = threading.Thread(target=self.timer_loop)
        self.thread.daemon = True  # 设置为守护线程，以便在主程序退出时自动停止
        self.thread.start()

############################bebug测试代码，记得注释掉#############################################

    def timer_loop(self):
        while True:
            # 生成一个包含 62 个 400 到 1000 之间随机数的列表
            data = [random.randint(400, 1000) for _ in range(62)]
            # 调用 data_process 函数处理数据
            if self.plot_idle == 1:
                self.plot_signal_data_info.emit(data)
            # 等待 ? 秒
            time.sleep(0.001)


    def data_process_thread_loop(self):
        while self.running:
            if self.pending_data:
                with self.data_lock:
                    data = self.pending_data.pop(0)
                self.data_process(data)
            else:
                time.sleep(0.1)  # 避免空转消耗过多 CPU


    def on_plot_signal_data_info(self, resistance):
        """ 处理 plot_signal_data_info 信号 """
        with self.data_lock:
            self.pending_data.append(resistance)



    def link_signal_handler(self, signal) -> None:
        """
        启动UDP server连接
        """
        link_type, my_ip, target_ip,my_port,target_port,self.time_step = signal
        if link_type == self.ServerUDP:
            self.udp_server_start(my_ip, target_ip,my_port,target_port,self.time_step)


    def disconnect_signal_handler(self) -> None:
        """关闭UDP server连接"""
        if self.link_flag == self.ServerUDP:
            self.udp_close()

    def send_signal_handler(self, msg: str) -> None:
        """发送按钮的槽函数"""
        if self.link_flag == self.ServerUDP:
            self.udp_send(msg)
            self.SendCounter = self.SendCounter+1
        self.counter_signal.emit(self.ReceiveCounter,self.SendCounter)


    def closeEvent(self, event) -> None:
        """
        重写closeEvent方法，实现MainWindow窗体关闭时执行一些代码
        :param event: close()触发的事件
        """
        self.disconnect_signal_handler()
        self.running = False  # 停止数据处理线程
        super().closeEvent(event)



    def data_process(self,input_numbers,a=400,b=1000):
        self.plot_idle=0#当前占用了画图函数，防止再次udq接收部分再次触发卡死进程
        self.step = self.step+1
        print("current step",self.step)
        start_time = time.time()
        self.fig1.clf()  # 清理画布
        ax = self.fig1.subplots()  # 主图
        #self.fig1.subplots_adjust(left=0.05, right=0.95, top=0.95, bottom=0.05)#减少周围的边距，使绘图区域更接近窗口的边缘
        ax.set_position([0.05, 0.05, 0.9, 0.9])  # [left, bottom, width, height]
        #ax = ax.ravel()
        ax.set_xlim(0, 125)
        ax.set_ylim(0, 265)
        ax.axis('off')
        ax.set_aspect('equal')

        for i in range(62):
            # 获取格子在输入中的位置
            selected_index = self.index_row[i]
            x, y = selected_index
            # 获取当前位的数字
            num = input_numbers[i]
            # 确保数值在 [a, b] 范围内
            num = max(min(num, b), a)
            # 将数值映射到 0-1 范围内
            normalized = (num - a) / (b - a)

            # 分段定义颜色
            if normalized < 0.5:
                # 蓝色到白色
                alpha = (0.5 - normalized) * 2
                red = 1 - alpha
                green = 1 - alpha
                blue = 1.0
            else:
                # 白色到红色
                alpha = (normalized - 0.5) * 2
                red = 1.0
                green = 1 - alpha
                blue = 1 - alpha

            # 将颜色分量限制在0到1之间
            red = max(0, min(red, 1))
            green = max(0, min(green, 1))
            blue = max(0, min(blue, 1))
            face_color = (red, green, blue)

            # 创建一个矩形，表示一个格子
            rect = patches.Rectangle((x, y), 6, 6, linewidth=1, edgecolor='black', facecolor=face_color)

            # 添加到图形中
            ax.add_patch(rect)

            # 设置字体属性
            fontprops = {
                'family': 'serif',  # 字体系列
                'style': 'normal',  # 字体风格
                'weight': 'bold',  # 字体粗细
                'size': 8  # 字体大小
            }

            # 在每个格子中添加文本以显示对应的数值
            ax.text(x + 3, y - 4, str(num), horizontalalignment='center', verticalalignment='center',
                    fontdict=fontprops, color='black')
        ax.text(0, 0, str('Squirrel'), horizontalalignment='center', verticalalignment='center',
                fontdict=fontprops, color='black')
        # 绘制新添加的点
        x_coords, y_coords = zip(*self.new_points)
        # ax.scatter(x_coords, y_coords, color='black', s=2, zorder=5)

        # 用黑色实线连接这些点
        ax.plot(x_coords, y_coords, color='black', linewidth=1, linestyle='-', zorder=4)

        '''
        # 创建图例轴
        divider = make_axes_locatable(ax)
        cax = divider.append_axes("right", size="3%", pad=0.2)
        # 创建颜色条
        norm = mpl.colors.Normalize(vmin=a, vmax=b)
        cmap = mpl.colors.LinearSegmentedColormap.from_list("custom", [(0, 'blue'), (0.5, 'white'), (1, 'red')])
        cb = mpl.colorbar.ColorbarBase(cax, cmap=cmap, norm=norm, orientation='vertical')
        cb.set_label('Value')
        '''
        self.fig1.canvas.draw()  # 这里注意是画布重绘，self.figs.canvas
        self.fig1.canvas.flush_events()  # 画布刷新self.figs.canvas
        # 结束计时
        end_time = time.time()
        total_time = end_time - start_time
        print(f"绘制整张图的时间: {total_time:.4f} 秒")
        self.plot_idle=1





if __name__ == '__main__':
    QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling)#高分辨率适应
    app = QApplication(sys.argv)  # 在 QApplication 方法中使用，创建应用程序对象
    myWin = MainWindow()  # 实例化 MyMainWindow 类，创建主窗口
    myWin.show()  # 在桌面显示控件 myWin
    sys.exit(app.exec_())  # 结束进程，退出程序