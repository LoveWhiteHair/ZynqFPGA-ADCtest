def format_num(num):
    if num >= 1000:
        return f"{num/1000:.1f}k"
    else:
        return str(num)

ax.text(x + 3, y - 4, format_num(num), horizontalalignment='center', verticalalignment='center',
        fontdict=fontprops, color='black')