import os
import csv
import numpy as np
import struct

#array[0]表示位置，array[1][2][3]表示电压值

#生成测试用bytes串
bytes1 = b'\x01\x00\x78\x00'
bytes2 = b'\x02\x87\xff\xff'
bytes3 = b'\x03\x00\x00\x00'
#bytes4 = b'\x04\x00\x00\x00'
bytes_array = bytearray()
bytes_array.extend(bytes1)
bytes_array.extend(bytes2)
bytes_array.extend(bytes3)
#bytes_array.extend(bytes4)
result_bytes = bytes(bytes_array)
print('result_bytes',result_bytes.hex())
resistance = [0.0] * 5



for i in range(0, len(result_bytes), 4):
    #if result_bytes[i]==0x57 and result_bytes[i+1]==0x91:
        #print('position 1')
    tem =  result_bytes[i+2]*256*256 +result_bytes[i+3]*256
    print('cal tem',tem)
    #if tem < 0x770000:
    if tem < 0x7fffff:
        print('position',result_bytes[i],'cal tem < 0x7ffffff')
        tem = tem
        print('new tem=',tem)
    elif tem >= 0x800000:
        print('position', result_bytes[i],'cal tem >= 0x800000')
        tem = tem - 0xffffff
        print('new tem=',tem)
    location = result_bytes[i]
    voltage=tem * 1500 * 1.0666665 / (2**23-1)
    resistance[location]=1500000 / (1500 - voltage)
    print('tem',tem)
    print('location',location)
    print('voltage',voltage)
    print('resistance',resistance)


