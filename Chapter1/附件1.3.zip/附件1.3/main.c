
/***************************** Include Files *********************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "xil_types.h"
#include "xparameters.h"

#include "axi_gpio_cfg/axi_gpio_cfg.h"
#include "axi_dma/axi_dma.h"
#include "sys_intr/sys_intr.h"
#include "udp_perf_server.h"

#include "platform.h"
#include "platform_config.h"


#include "lwip/priv/tcp_priv.h"
#include "lwip/init.h"
#include "lwip/inet.h"
#include "lwip/tcp.h"

#include "sleep.h"
#include "xil_printf.h"
#include "xil_cache.h"
#include "netif/xadapter.h"



#define DEFAULT_IP_ADDRESS  "192.168.1.10"
#define DEFAULT_IP_MASK     "255.255.255.0"
#define DEFAULT_GW_ADDRESS  "192.168.1.1"

void start_application(void);
void print_app_header(void);
int lwip_udp_init();
#define MAX_PKT_LEN     4096    //send data count
#define SEND_PKT_LEN     256

//function declaration
struct netif *netif;
extern volatile int rx_done;
extern u32 *rx_buffer_ptr;
u32 fifo_count = 0;
u8 dma_start_flag = 0;

struct netif server_netif;
static XScuGic Intc;              //GIC


int main(void)
{
    axi_gpio_init();               // init AXI-GPIO//axi_gpio_cfg.c
    axi_dma_cfg();                 // set AXI DMA//axi_dma.c
    Init_Intr_System(&Intc);       // init DMA intr system//sys_intr.c
    Setup_Intr_Exception(&Intc);   // init intr//sys_intr.c
    dma_setup_intr_system(&Intc);  // setup DMA intr system//axi_dma.c
    lwip_udp_init();               // init UDP communication//main.c

    //receive data package
    while (1)
    {

        xemacif_input(netif);


        //read data from fifo to ddr
        if((dma_start_flag == 0))
        {
            //axi_gpio_out1();
            //sleep(0.5);
            axi_dma_start(MAX_PKT_LEN);
            //axi_gpio_out0();
            dma_start_flag = 1;

        }
        //udp send ddr data
        if(rx_done)
        {
        	xil_printf("rx_done");
        	for (int i=1;i<=MAX_PKT_LEN/SEND_PKT_LEN/4;i=i+1)
        	{
            	udp_tx_data(rx_buffer_ptr, SEND_PKT_LEN*sizeof(u32));//0-255
            	rx_buffer_ptr = (u32 *) 0x01400000+0x00000100 * i;//0x01400400,beginning for data 00000100
        	}

        	/*
        	//for SEND_PKT_LEN=8192
        	udp_tx_data(rx_buffer_ptr, SEND_PKT_LEN*sizeof(u32));//0-255
        	rx_buffer_ptr = (u32 *) 0x01400000+0x00000100;//0x01400400,beginning for data 00000100
            rx_buffer_ptr = (u32 *) 0x01400000+0x00002000;//0x01408000,beginning for data 00002000
            udp_tx_data(rx_buffer_ptr, SEND_PKT_LEN*sizeof(u32));//8192-8448
            */
            rx_buffer_ptr = (u32 *) 0x01400000;//turn to original address
            //udp_tx_data(rx_buffer_ptr, SEND_PKT_LEN*sizeof(u32));//address test code
            rx_done = 0;
            dma_start_flag = 0;
        }

    }
    return 0;
}

static void print_ip(char *msg, ip_addr_t *ip)
{
    print(msg);
    xil_printf("%d.%d.%d.%d\r\n", ip4_addr1(ip), ip4_addr2(ip),
               ip4_addr3(ip), ip4_addr4(ip));
}

static void print_ip_settings(ip_addr_t *ip, ip_addr_t *mask, ip_addr_t *gw)
{
    print_ip("Board IP:       ", ip);
    print_ip("Netmask :       ", mask);
    print_ip("Gateway :       ", gw);
}

//set static ip
static void assign_default_ip(ip_addr_t *ip, ip_addr_t *mask, ip_addr_t *gw)
{
    int err;

    xil_printf("Configuring default IP %s \r\n", DEFAULT_IP_ADDRESS);

    err = inet_aton(DEFAULT_IP_ADDRESS, ip);
    if (!err)
        xil_printf("Invalid default IP address: %d\r\n", err);

    err = inet_aton(DEFAULT_IP_MASK, mask);
    if (!err)
        xil_printf("Invalid default IP MASK: %d\r\n", err);

    err = inet_aton(DEFAULT_GW_ADDRESS, gw);
    if (!err)
        xil_printf("Invalid default gateway address: %d\r\n", err);
}

int lwip_udp_init()
{
    /*MAC address */
    unsigned char mac_ethernet_address[] =
    {
        0x00, 0x0a, 0x35, 0x00, 0x01, 0x02
    };

    netif = &server_netif;

    xil_printf("\r\n\r\n");
    xil_printf("-----lwIP RAW Mode UDP Server Application-----\r\n");

    /* init lwIP*/
    lwip_init();

    /* add net port to netif_list and set as default  */
    if (!xemac_add(netif, NULL, NULL, NULL, mac_ethernet_address,
                   PLATFORM_EMAC_BASEADDR))
    {
        xil_printf("Error adding N/W interface\r\n");
        return -1;
    }
    netif_set_default(netif);

    //if net is started
    netif_set_up(netif);

    //set static IP
    assign_default_ip(&(netif->ip_addr), &(netif->netmask), &(netif->gw));

    //print IP settings
    print_ip_settings(&(netif->ip_addr), &(netif->netmask), &(netif->gw));

    xil_printf("\r\n");

    /* print app title */
    print_app_header();

    /* start app application*/
    start_application();
    xil_printf("\r\n");
    return 0;
}
