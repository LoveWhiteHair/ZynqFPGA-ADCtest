#include"axi_gpio_cfg.h"

#define AXI_GPIO_0_ID XPAR_AXI_GPIO_0_DEVICE_ID	//AXI GPIO 0 device ID
#define AXI_GPIO_0_CHANEL1   1

XGpio   axi_gpio_inst0;      //AXI GPIO 0 driver instance

//AXI GPIO init
void axi_gpio_init(void)
{
    //AXI GPIO 0 driver
    XGpio_Initialize(&axi_gpio_inst0, AXI_GPIO_0_ID);
    //set AXI GPIO 0 use channel 1 for output
    XGpio_SetDataDirection(&axi_gpio_inst0, AXI_GPIO_0_CHANEL1,0);
}

//use AXI GPIO to get FIFO data count
//u32 get_fifo_count(void)
//{
//    u32 fifo_count = 0;
//    fifo_count = XGpio_DiscreteRead(&axi_gpio_inst0, AXI_GPIO_0_CHANEL1);
//    return fifo_count;
//}
void axi_gpio_out1(void)
{
	XGpio_DiscreteWrite(&axi_gpio_inst0, 1, 0x01);
	}

void axi_gpio_out0(void)
{
	XGpio_DiscreteWrite(&axi_gpio_inst0, 1, 0x00);
	}

