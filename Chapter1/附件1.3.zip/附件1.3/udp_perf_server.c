#include <stdio.h>
#include <string.h>
#include "lwip/err.h"
#include "lwip/udp.h"
#include "xil_printf.h"
#include "lwip/inet.h"

static struct udp_pcb *pcb;

#define SER_PORT 8000

//print app title
void print_app_header()
{
    xil_printf("\r\n-----Network port UDP transmission adc sample data on upper computer ------\r\n");
}

//UDP send data function
void udp_tx_data(u32 *buffer_ptr,unsigned int len){
    static struct pbuf *ptr;

    ptr = pbuf_alloc(PBUF_TRANSPORT, len, PBUF_POOL); //apply for buffer

    if (ptr)
    {
        pbuf_take(ptr, buffer_ptr,len); /* package uffer_ptr data to pbuf */
        udp_send(pcb, ptr);              /* udp send data */
        pbuf_free(ptr);                  /* free pbuf */
    }
}

void start_application()
{
    err_t err;

    /* set client IP */

    ip_addr_t DestIPaddr;

    IP4_ADDR( &DestIPaddr,192,168,1,102);

    //create UDP PCB
    pcb = udp_new();
    if (!pcb) {
        xil_printf("Error creating PCB. Out of Memory\r\n");
        return;
    }

    //bind port
    err = udp_bind(pcb, IP_ADDR_ANY, SER_PORT);//use port 8000
    if (err != ERR_OK) {
        xil_printf("Unable to bind to port %d; err %d\r\n",
                SER_PORT, err);
        udp_remove(pcb);
        return;
    }
    /* set client port */
    udp_connect(pcb, &DestIPaddr, 8000);//use port 8000

    xil_printf("UDP server started @ port %d\n\r", SER_PORT);
}

