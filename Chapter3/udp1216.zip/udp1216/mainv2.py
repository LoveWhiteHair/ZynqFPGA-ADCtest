import csv
import math
import os
from signal import signal

from PyQt5.QtWidgets import QApplication,QGridLayout
from PyQt5 import QtCore
import socket
import sys
import threading



#user file
import MainWindowUI
from mainwindowlogic import *#UI界面逻辑功能和len_signal全局变量
from Network import NetworkLogic #Network库，内部定义了UDP逻辑
#画图
import numpy as np
import matplotlib.pyplot as plt
import struct
import scipy.signal
import time
from UI.MyWidgets import MyFigure



class MainWindow(WidgetLogic, NetworkLogic):
    def __init__(self, parent=None):
        super().__init__(parent)
        #检测屏幕分辨率
        self.desktop = QApplication.desktop()
        self.screenRect = self.desktop.screenGeometry()
        self.screenheight = self.screenRect.height()
        self.screenwidth = self.screenRect.width()
        self.height = int(self.screenheight * 0.7)
        self.width = int(self.screenwidth * 0.7)
        print("Screen height {}".format(self.screenheight))
        print("Screen width {}".format(self.screenwidth))
        self.resize(self.width, self.height)



        self.time_step = 0
        self.input_fs = 0
        self.step = 0
        self.gain = 0
        self.plot_flag=1


        self.link_signal.connect(self.link_signal_handler)#连接至udp服务器
        self.disconnect_signal.connect(self.disconnect_signal_handler)#关闭连接
        self.send_signal.connect(self.send_signal_handler)#数据发送模块
        self.udp_signal_write_msg.connect(self.msg_write)#udp连接信息显示
        self.udp_signal_write_info.connect(self.info_write)#udp接收数据显示
        self.udp_signal_len_info.connect(self.len_write)#udp接收长度label显示
        self.plot_signal_data_info.connect(self.data_process)#接收画图数据被触发后进行画图函数
        #debug测试代码
        '''
        num_groups = 200
        # 创建一个空的bytes数组
        bytes_array = bytearray()
        # 生成每组数据
        for i in range(1, num_groups + 1):
            # 将计数器i转换为小端格式的两个字节
            count_bytes = i.to_bytes(2, 'little')
            # 后两字节从小于00 00递增到07 00
            # 计算后两字节的值，循环从0到7
            increment = (i - 1) % 8
            fixed_bytes = (increment).to_bytes(1, 'little') + b'\x00'
            # 将计数字节和固定字节组合
            bytes_array.extend(count_bytes)
            bytes_array.extend(fixed_bytes)
        # 将bytearray转换为bytes
        result_bytes = bytes(bytes_array)
        self.data_process(result_bytes)
        '''


    def link_signal_handler(self, signal) -> None:
        """
        启动UDP server连接
        """
        link_type, my_ip, target_ip,my_port,target_port,self.time_step,self.input_fs,self.gain = signal
        if link_type == self.ServerUDP:
            self.udp_server_start(my_ip, target_ip,my_port,target_port,self.time_step,self.input_fs)


    def disconnect_signal_handler(self) -> None:
        """关闭UDP server连接"""
        if self.link_flag == self.ServerUDP:
            self.udp_close()

    def send_signal_handler(self, msg: str) -> None:
        """发送按钮的槽函数"""
        if self.link_flag == self.ServerUDP:
            self.udp_send(msg)
            self.SendCounter = self.SendCounter+1
        self.counter_signal.emit(self.ReceiveCounter,self.SendCounter)


    def closeEvent(self, event) -> None:
        """
        重写closeEvent方法，实现MainWindow窗体关闭时执行一些代码
        :param event: close()触发的事件
        """
        self.disconnect_signal_handler()




    def data_process(self,data_bytes_origin):
        self.step = self.step+1
        print("current step",self.step)
        time_label1 = time.perf_counter()
        data_length_origin = len(data_bytes_origin)#总原始数据长度
        self.plot_bytes_total=self.plot_bytes_total[-(self.plot_byte-data_length_origin):]+data_bytes_origin
        plot_bytes=self.plot_bytes_total
        # debug测试代码
        #plot_bytes = data_bytes_origin
        data_length=int(len(plot_bytes)/4)#数据量总长度
        current_channel = 0
        last_channel = 1
        data_index = 0
        err_index = []
        err_cnt = 0
        c_arr = [[] for _ in range(8)]  # 定义八个空列表用来放数据
        c_cnt = [0] * 8  # 八个空元素的列表，用来记录每个通道的数据量
        for i in range(0, data_length):
            current_channel = int.from_bytes(plot_bytes[2+4*i:2+4*i+2], 'little')
            two_bytes = plot_bytes[data_index:data_index + 2]  # 通道对应的数据字节
            data_index += 4
            temp_int = struct.unpack('<H', bytes(two_bytes))[0]  # 大端,2字节数据格式,解码
            c_arr[current_channel].append(temp_int)  # 数据转换成int格式,存放到对应通道的数组中
            c_cnt[current_channel] += 1  # 对应通道的计数器+1
            if i != 0 and not (current_channel - last_channel == 1 or current_channel - last_channel == -7):
                err_cnt += 1
                err_index.append(3 * i)
            last_channel = current_channel
        #print(f'每通道的数据数量{c_cnt}')
        #print(f'异常数据数量{err_cnt}')
        #print(f'异常数据地址{err_index}')
        time_label2 = time.perf_counter()
        print('数据转换运行时间:', time_label2 - time_label1, 's')
        data_length = self.input_fs * 10#总的画图长度
        #debug测试代码
        '''
        data_length = 20
        self.gain=1
        self.input_fs=1
        '''
        data_length = int(data_length)
        data_length = min(data_length,min(c_cnt))#画图长度取希望的总画图长度与当前已有长度的最小值
        print("当前画图长度",data_length)
        data_save_path = f'data_trans/fs{self.input_fs}/gain{self.gain}/step{self.time_step}'
        if not os.path.exists(data_save_path):
            os.makedirs(data_save_path)
        run_save_path = f'runlog/fs{self.input_fs}/gain{self.gain}/step{self.time_step}'
        #画图函数
        if self.plot_flag==1:
            self.plot_flag=0
            time_label1 = time.perf_counter()
            final_output = []  # diff_voltage输出结果
            self.fig1.clf()  # 清理画布
            self.fig2.clf()  # 清理画布
            ax1 = self.fig1.subplots(2, 2, sharey=False)
            ax2 = self.fig2.subplots(2, 2, sharey=False)
            ax1 = ax1.ravel()
            ax2 = ax2.ravel()
            time_label = np.linspace(0, data_length - 1, data_length) * 1 / self.input_fs
            for channel_index in range(0, 4):  # 通道0到通道3
                scan_arr = c_arr[channel_index][-data_length:]#取数组的最后data_length位
                max_value = max(scan_arr)  # 求列表最大值
                max_idx = scan_arr.index(max_value)  # 求最大值对应索引
                min_value = min(scan_arr)  # 求列表最小值
                min_idx = scan_arr.index(min_value)  # 求最小值对应索引
                data_diff = max_value - min_value
                diff_volt = data_diff * 3.6  / 65536 * 1000000/ self.gain
                scan_arr = np.array(scan_arr)
                #scan_arr = scan_arr - min_value
                ax1[channel_index].cla()
                ax1[channel_index].plot(time_label, (scan_arr * 3.6  / 65536-1.8) * 1000000 /self.gain, 'k-')
                ax1[channel_index].text(data_length * 1 / self.input_fs / 6, diff_volt,'max={:.4f}uV'.format(diff_volt), size=10, color='gray')
                ax1[channel_index].scatter(max_idx * 1 / self.input_fs, (max_value  * 3.6/ 65536-1.8 )  * 1000000/ self.gain, s=25, c='r')
                ax1[channel_index].scatter(min_idx * 1 / self.input_fs, (min_value  * 3.6/ 65536-1.8 )  * 1000000/ self.gain, s=25, c='g')
                ax1[channel_index].set_title(f'channel{channel_index}')
                for ax in ax1.flat:
                    ax.set(xlabel='Time/s', ylabel='Voltage/uV')
                final_output.append(diff_volt)
                with open(f'{data_save_path}/channel{channel_index}.csv', mode='a', newline='') as file:
                    file.write(f'run{self.step}' + '\n')
                    writer = csv.writer(file)
                    writer.writerow(time_label)
                    writer.writerow(scan_arr)
            for channel_index in range(4, 8):  # 通道4到通道7
                scan_arr = c_arr[channel_index][0:data_length]
                max_value = max(scan_arr)  # 求列表最大值
                max_idx = scan_arr.index(max_value)  # 求最大值对应索引
                min_value = min(scan_arr)  # 求列表最小值
                min_idx = scan_arr.index(min_value)  # 求最小值对应索引
                data_diff = max_value - min_value
                diff_volt = data_diff * 3.6 * 1000000 / 65536 / self.gain
                scan_arr = np.array(scan_arr)
                #scan_arr = scan_arr - min_value
                ax2[channel_index-4].cla()
                ax2[channel_index-4].plot(time_label, (scan_arr * 3.6  / 65536-1.8) * 1000000 /self.gain, 'k-')
                ax2[channel_index-4].text(data_length * 1 / self.input_fs / 6, diff_volt,'max={:.4f}uV'.format(diff_volt), size=10, color='gray')
                ax2[channel_index-4].scatter(max_idx * 1 / self.input_fs, (max_value  * 3.6/ 65536-1.8 )  * 1000000/ self.gain, s=25, c='r')
                ax2[channel_index-4].scatter(min_idx * 1 / self.input_fs, (min_value  * 3.6/ 65536-1.8 )  * 1000000/ self.gain, s=25, c='g')
                ax2[channel_index-4].set_title(f'channel{channel_index}')
                for ax in ax2.flat:
                    ax.set(xlabel='Time/s', ylabel='Voltage/uV')
                final_output.append(diff_volt)
                with open(f'{data_save_path}/channel{channel_index}.csv', mode='a', newline='') as file:
                    file.write(f'run{self.step}' + '\n')
                    writer = csv.writer(file)
                    writer.writerow(time_label)
                    writer.writerow(scan_arr)
            if not os.path.exists(run_save_path):
                os.makedirs(run_save_path)
            self.fig1.savefig(f'{run_save_path}/c0-3_run{self.step}.png')
            self.fig2.savefig(f'{run_save_path}/c4-7_run{self.step}.png')
            self.fig1.canvas.draw()  # 这里注意是画布重绘，self.figs.canvas
            self.fig1.canvas.flush_events()  # 画布刷新self.figs.canvas
            self.fig2.canvas.draw()  # 这里注意是画布重绘，self.figs.canvas
            self.fig2.canvas.flush_events()  # 画布刷新self.figs.canvas
            time_label2 = time.perf_counter()
            print('画图运行时间:', time_label2 - time_label1, 's')
            with open(f'{run_save_path}/runlog.txt', 'a') as f:
                f.write(f'current run:run{self.step}\r\n')
                for i in range(0, 8):
                    f.write(f'Channel{i} max-min result:')
                    f.write(str(final_output[i]))
                    f.write('uV\r\n')
            self.plot_flag = 1

if __name__ == '__main__':
    QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling)#高分辨率适应
    app = QApplication(sys.argv)  # 在 QApplication 方法中使用，创建应用程序对象
    myWin = MainWindow()  # 实例化 MyMainWindow 类，创建主窗口
    myWin.show()  # 在桌面显示控件 myWin
    sys.exit(app.exec_())  # 结束进程，退出程序