import re
import threading
import time
import datetime
from PyQt5 import QtCore
from os import fstat

from PyQt5.QtCore import Qt, QTimer, pyqtSignal
from PyQt5.QtWidgets import QFileDialog, QMessageBox, QWidget, QMainWindow,QGridLayout

#user file
from Network import get_host_ip,get_board_ip
import MainWindowUI
from UI.MyWidgets import PortInputDialog#自定义widgets
#matplotlib
import matplotlib as mpl
mpl.use('Qt5Agg')# 声明使用pyqt5
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar
import matplotlib.pyplot as plt

#length_signal=0

class WidgetLogic(QMainWindow):
    link_signal = pyqtSignal(tuple)  # 连接类型, 本机IP，目标IP, 本机端口，目标端口, 刷新时间，fs，gain
    disconnect_signal = pyqtSignal()
    counter_signal = pyqtSignal(int,int)#rx计数，tx计数
    fft_signal = pyqtSignal(str,str,str)
    send_signal = pyqtSignal(str)
    rx_num_signal = pyqtSignal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        #变量定义
        self.userfile_write_str_flag = None
        self.send_userfile_thread = None
        self.userfile_write_str = None
        self.userfile = "None"
        self.SendCounter = 0
        self.udp_per_rx = None
        #图像
        self.figtoolbar1 = None
        self.canvas1 = None
        self.fig1 = None
        self.figtoolbar2 = None
        self.canvas2 = None
        self.fig2 = None
        #网络连接
        self.protocol_type = "UDP"  #连接类型
        self.link_flag = self.NoLink #连接状态flag
        self.receive_show_flag = True  # 是否显示接收到的消息
        self.ReceiveCounter = 0 #接收数据计数


        #MainwindowUI
        self.__ui = MainWindowUI.Ui_MainWindow()
        self.__ui.setupUi(self)
        self.__ui.retranslateUi(self)

        #输入框初始值设定
        #self.setWindowFlags(Qt.WindowStaysOnTopHint)  # 保持窗口最前
        self.__ui.MyHostAddrLineEdit.setText(get_host_ip())  # 显示本机IP地址
        self.__ui.MyPortLineEdit.setText(str(9000))  # 默认端口为9000
        self.__ui.TargetPortLineEdit.setText(str(9000))  # 默认端口为9000=
        self.__ui.TargetIPLineEdit.setText('192.168.1.30')
        self.__ui.TimestepLineEdit.setText(str(2))

        #信号触发与槽函数连接
        self.counter_signal.connect(self.counter_signal_handler)#将counter signal信号连接到counter_signal_handler槽函数
        self.__ui.pushButton_IP.clicked.connect(self.set_board_ip)
        self.__ui.ConnectButton.toggled.connect(self.connect_button_toggled_handler)#将连接按钮按住动作连接到connect_button_toggled_handler槽函数
        self.__ui.SendButton.clicked.connect(self.send_link_handler)#将发送按钮按住动作连接到send_link_handler槽函数
        self.__ui.FileSendButton.clicked.connect(self.file_send_link_handler)#将配置文件发送按钮按住动作连接到file_send_link_handler槽函数
        self.__ui.CounterResetLabel.clicked.connect(self.counter_reset_button_handler)#将复位计数按钮点击动作连接到counter_reset_button_handler槽函数
        self.__ui.ReceivePauseCheckBox.toggled.connect(
            self.receive_pause_checkbox_toggled_handler
        )#将暂停接收显示按钮按住动作连接到receive_pause_checkbox_toggled_handler槽函数
        self.__ui.comboBox.activated[str].connect(self.combobox_handler)

        #绘画界面UI初始化
        self.plot_ui()

    def connect_button_toggled_handler(self, state):
        if state:
            # 连接按钮连接
            self.click_link_handler()
        else:
            # 连接按钮断开连接
            self.click_disconnect()
            self.editable(True)

    def editable(self, able: bool = True):
        """当连接建立后，部分选项不可再修改"""
        self.__ui.MyPortLineEdit.setReadOnly(not able)
        self.__ui.MyHostAddrLineEdit.setReadOnly(not able)
        self.__ui.TargetIPLineEdit.setReadOnly(not able)
        self.__ui.TargetPortLineEdit.setReadOnly(not able)
        self.__ui.TimestepLineEdit.setReadOnly(not able)
        self.__ui.SendPlainTextEdit.setEnabled(True)

    def combobox_handler(self, userfile_name):
        self.userfile = userfile_name
        if self.userfile == "None":
            self.userfile_write_str=[]#配置文件内用户需要发送的str内容
        else:
            file_path = f'user_file/{userfile_name}.txt'

            # 正则表达式匹配6个十六进制数字,头部非#
            hex_pattern = re.compile(r'(?<!#)0x([A-Fa-f0-9]{6})')

            try:
                # 打开TXT文件
                with open(file_path, mode='r', encoding='utf-8') as file:
                    # 读取所有行
                    self.userfile_write_str = []
                    for line in file:
                        # 使用正则表达式查找匹配的行
                        matches = hex_pattern.findall(line)
                        for match in matches:
                            # 将十六进制数转换为二进制字符串
                            hex_str = match  # 提取匹配的6个十六进制数字
                            binary_str = bin(int(hex_str, 16))[2:].zfill(24)  # 转换为24位二进制数
                            self.userfile_write_str.append(binary_str)
                    self.userfile_write_str_flag = 1
            except FileNotFoundError:
                self.msg_write(f'配置文件{self.userfile}未找到\n')
                self.userfile_write_str_flag = 0
            except Exception as e:
                self.msg_write(f"读取文件时发生错误：{e}\n")
                self.userfile_write_str_flag = 0

    def click_link_handler(self):
        """连接按钮连接时的槽函数"""
        server_flag = True  # Server/Client模式标识符
        my_ip = str(self.__ui.MyHostAddrLineEdit.text())
        target_ip = str(self.__ui.TargetIPLineEdit.text())
        def get_int_data(port):
            # 用户未输入端口则置为-1
            return -1 if port == "" else int(port)
        def get_float_data(port):
            # 用户未输入端口则置为-1
            return -1 if port == "" else float(port)
        my_port = get_int_data(self.__ui.MyPortLineEdit.text())#获取UI端MyPortLineEdit中输入的端口号
        target_port = get_int_data(self.__ui.TargetPortLineEdit.text())
        time_step = get_int_data(self.__ui.TimestepLineEdit.text())#获取UI端RxPointLineEdit中输入的采样字节数
        fs= get_float_data(self.__ui.fsLineEdit.text())#获取UI端fsLineEdit中输入
        gain= get_int_data(self.__ui.GainLineEdit.text())#获取UI端OSRLineEdit中输入
        self.editable(False)  # 建立连接后不可再修改参数

        if  (my_port==-1 and target_port==-1 and target_ip=="") or time_step==-1 or fs==-1 or gain==-1 :
            mb = QMessageBox(QMessageBox.Critical, "错误", "请输入信息", QMessageBox.Ok, self)
            mb.open()#若没有输入完整信息，弹出错误消息提示
            self.editable(True)
            self.__ui.ConnectButton.setChecked(False)
            return None

        if self.protocol_type == "UDP" and server_flag:#udp服务端
            self.link_signal.emit((self.ServerUDP, my_ip,target_ip, my_port,target_port,time_step,fs,gain))
            self.link_flag = self.ServerUDP
            self.__ui.StateLabel.setText('UDP服务端')


    def send_link_handler(self):
        """
        SendButton控件点击触发的槽
        """
        if self.link_flag != self.NoLink:
            send_msg = self.__ui.SendPlainTextEdit.toPlainText()
            self.send_signal.emit(send_msg)

    def file_send_link_handler(self):
        if self.userfile_write_str_flag:
            self.send_userfile_thread = threading.Thread(target=self.file_send_link_handler_concurrency)
            self.send_userfile_thread.start()

    def file_send_link_handler_concurrency(self):
        """
        用于创建一个线程发送配置文件
        """
        if self.link_flag != self.NoLink:
            length = len(self.userfile_write_str)
            self.msg_write(f'当前发送配置文件{self.userfile}\n')
            for i in range(length):
                send_msg=self.userfile_write_str[i]
                self.send_signal.emit(send_msg)
                if i < length - 1:
                    time.sleep(0.5)  # 每条发完后等待



    def msg_write(self, msg: str):
        """将提示消息写入ReceivePlainTextEdit"""
        if self.receive_show_flag:
            self.__ui.ReceivePlainTextEdit.appendPlainText(msg)

    def info_write(self, info: str, mode: int,rx_num: int):#receive counter计数
        """
        将接收到或已发送的消息写入ReceivePlainTextEdit
        :param rx_num: 接收到的数据量（字节数）
        :param info: 接收或发送的消息
        :param mode: 模式，接收/发送
        :return: None
        """
        if self.receive_show_flag:
            if mode == self.InfoRec:
                self.__ui.ReceivePlainTextEdit.appendHtml(
                    f'<font color="blue">{info}</font>'
                )
                self.ReceiveCounter += rx_num
                self.counter_signal.emit(self.ReceiveCounter,self.SendCounter)
            elif mode == self.InfoSend:
                self.__ui.ReceivePlainTextEdit.appendHtml(
                    f'<font color="green">{info}</font>'
                )
            self.__ui.ReceivePlainTextEdit.appendHtml("\n")
        else:
            if mode == self.InfoRec:
                self.ReceiveCounter += rx_num
                self.counter_signal.emit(self.ReceiveCounter,self.SendCounter)

        self.udp_per_rx = rx_num

    def len_write(self, rx_num: int):#receive counter计数
        self.ReceiveCounter += rx_num
        self.counter_signal.emit(self.ReceiveCounter,self.SendCounter)
        self.udp_per_rx = rx_num

    def click_disconnect(self):
        self.disconnect_signal.emit()
        self.link_flag = self.NoLink
        self.__ui.StateLabel.setText("未连接")

    def counter_signal_handler(self, receive_count,send_count):
        """控制接收计数器显示变化的槽函数"""
        self.__ui.ReceiveCounterLabel.setText(str(receive_count))#将接收ReceiveCounterLabel的值设置为receive_count
        self.__ui.SendCounterLabel.setText(str(send_count))

    def counter_reset_button_handler(self):#将ReceiveCounter设置为0
        """清零计数器的槽函数"""
        self.ReceiveCounter = 0
        self.SendCounter = 0
        self.counter_signal.emit(self.ReceiveCounter,self.SendCounter)


    def receive_pause_checkbox_toggled_handler(self, ste: bool):
        """暂停接受复选框的槽函数"""
        if ste:
            self.receive_show_flag = False
        else:
            self.receive_show_flag = True

    def plot_ui(self):
        #绘画数据
        self.fig1 = plt.figure()  # 创建figure对象
        self.canvas1 = FigureCanvas(self.fig1)  # 创建figure画布
        self.figtoolbar1 = NavigationToolbar(self.canvas1, self)  # 创建figure工具栏
        self.fig2 = plt.figure()  # 创建figure对象
        self.canvas2 = FigureCanvas(self.fig2)  # 创建figure画布
        self.figtoolbar2 = NavigationToolbar(self.canvas2, self)  # 创建figure工具栏
        #布局
        self.gridlayout1 = QGridLayout(self.__ui.groupBox1)  # 继承容器groupBox
        self.gridlayout1.addWidget(self.canvas1)  # 画布添加到窗口布局中
        self.gridlayout1.addWidget(self.figtoolbar1)  # 工具栏添加到窗口布局中
        self.gridlayout2 = QGridLayout(self.__ui.groupBox2)  # 继承容器groupBox
        self.gridlayout2.addWidget(self.canvas2)  # 画布添加到窗口布局中
        self.gridlayout2.addWidget(self.figtoolbar2)  # 工具栏添加到窗口布局中

    def set_board_ip(self):
        self.__ui.MyHostAddrLineEdit.setText(get_board_ip())  # 显示本机IP地址





    NoLink = -1
    ServerUDP = 2
    ClientUDP = 3


    #print("当前len值为%d" % length_signal)
if __name__ == "__main__":
    import sys
    from PyQt5.QtWidgets import QApplication

    #QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling)#高分辨率适应

    app = QApplication(sys.argv)
    window = WidgetLogic()
    window.show()
    sys.exit(app.exec_())
