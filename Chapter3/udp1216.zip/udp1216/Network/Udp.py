import socket
import threading
import struct
import time

from PyQt5.QtCore import pyqtSignal
from . import StopThreading


def get_host_ip() -> str:
    """获取本机IP地址"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]

        #hostname = socket.gethostname()
        #ip = socket.gethostbyname(hostname)

    finally:
        s.close()
    return ip

def get_board_ip():
    hostname = socket.gethostname()
    board_ip = socket.gethostbyname(hostname)
    return board_ip

class UdpLogic:
    udp_signal_write_msg = pyqtSignal(str)
    udp_signal_write_info = pyqtSignal(str, int,int)#for str
    #udp_signal_write_info = pyqtSignal(bytes, int, int)#for bytes
    plot_signal_data_info = pyqtSignal(bytes)#bytes数据，接收数据（字节）
    udp_signal_len_info = pyqtSignal(int)#int数据，接收数据长度（字节）
    udp_save_str_info = pyqtSignal(str)#接收到的str格式数据

    def __init__(self):
        self.sever_tr = None
        self.sever_rx = None
        self.plot_bytes_total = None
        self.plot_byte = 0
        self.need_byte = 0
        self.send_address = None
        self.num_cnt = 0#接收字节数counter
        self.int_info = None
        self.rx_num = None
        self.link_flag = False#udp连接状态
        self.udp_socket = None#udp嵌套字


    def udp_server_start(self, my_ip: str,target_ip: str,my_port: int,target_port: int,time_step:int,fs) -> None:
        """
        开启UDP服务端
        """

        self.udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)#建立UDP套接字
        self.udp_socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 1024 * 1024)#设置接收缓冲区大小为1MB
        my_port = int(my_port)
        my_address = (my_ip, my_port)
        target_port=int(target_port)
        self.send_address = (target_ip, target_port)
        self.udp_socket.bind(my_address)
        self.sever_rx = threading.Thread(target=self.udp_server_concurrency)
        self.sever_rx.start()
        msg = "UDP服务端正在监听端口:{}\n".format(my_port)
        self.udp_signal_write_msg.emit(msg)
        msg = "当前设置的刷新频率:{}s\n".format(time_step)
        self.udp_signal_write_msg.emit(msg)
        msg = "当前设置的采样频率:{}Hz\n".format(fs)
        self.udp_signal_write_msg.emit(msg)
        self.need_byte = int(4*8*fs*time_step)
        self.plot_byte = int(4*8*fs*10)#总的需求字节为4字节*8通道*采样率*10s
        msg = "计算每次需要接收的字节数4字节*8通道*fs*刷新时间={}bytes\n".format(self.need_byte)
        self.udp_signal_write_msg.emit(msg)
        self.plot_bytes_total = bytearray(self.plot_byte)
        print("plot_bytes_total initialized")
    def udp_server_concurrency(self) -> None:
        """
        用于创建一个线程持续监听UDP通信
        """

        while True:
        #while self.plot_done_flag:
            time1 = time.perf_counter()  # 接收开始时间
            total_bytes_info = b''#最终65536字节的bytes数据
            total_info = '' #最终字符串
            self.num_cnt = 0#函数内部计数变量


            while self.num_cnt<self.need_byte+1:
                recv_msg, recv_addr = self.udp_socket.recvfrom(1024)
                if self.num_cnt == 0:
                    msg = f"来自IP:{recv_addr[0]}端口:{recv_addr[1]}:"
                    self.udp_signal_write_msg.emit(msg)  # 当前监听地址和端口号
                info = recv_msg.hex() #HEX解码
                bytes_info = bytes.fromhex(info)# 将字符串转换为hex格式bytes数据
                rx_num_once = len(bytes_info)  # 读取本次接收的数据长度（字节）
                self.num_cnt =self.num_cnt + rx_num_once
                total_bytes_info += bytes_info
                total_info += info
                #self.udp_signal_write_info.emit(info, self.InfoRec, rx_num_once)  # 接收到的str格式数据，接收到的字节数量
            self.udp_signal_len_info.emit(self.num_cnt)#发送总的接收到的字节数量给数据显示模块
            self.udp_save_str_info.emit(total_info)

            #输出信息
            self.plot_signal_data_info.emit(total_bytes_info)#向画图函数传递接收到的bytes数据
            print("本次接收长度", self.num_cnt)
            self.num_cnt = 0  # 清零计数
            time2 = time.perf_counter()  # 接收完成时间
            print("接收数据耗时", time2 - time1)


    def udp_send(self, send_info: str) -> None:
        """
        功能函数，用于UDP客户端发送消息
        """
        try:
            send_info_encoded = send_info.encode("utf-8")
            self.udp_socket.sendto(send_info_encoded, self.send_address)
            msg = "UDP客户端已发送"
            self.udp_signal_write_msg.emit(msg)
            self.udp_signal_write_info.emit(send_info, self.InfoSend,0)
        except Exception as ret:
            msg = "发送失败\n"
            self.udp_signal_write_msg.emit(msg)


    def udp_close(self) -> None:
        """
        功能函数，关闭网络连接的方法
        """
        if self.link_flag == self.ServerUDP:
            try:
                self.udp_socket.close()
                msg = "已断开网络\n"
                self.udp_signal_write_msg.emit(msg)
            except Exception as ret:
                pass

            try:
                StopThreading.stop_thread(self.sever_rx)
            except Exception:
                pass


    NoLink = -1
    ServerUDP = 2
    ClientUDP = 3
    InfoSend = 0
    InfoRec = 1
