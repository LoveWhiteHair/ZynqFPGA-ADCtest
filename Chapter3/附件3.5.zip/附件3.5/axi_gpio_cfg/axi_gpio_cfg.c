#include"axi_gpio_cfg.h"

#define AXI_GPIO_0_ID XPAR_AXI_GPIO_0_DEVICE_ID	//AXI GPIO 0 device ID
#define AXI_GPIO_1_ID XPAR_AXI_GPIO_1_DEVICE_ID	//AXI GPIO 1 device ID
#define AXI_GPIO_2_ID XPAR_AXI_GPIO_2_DEVICE_ID	//AXI GPIO 2 device ID
#define CHANEL1   1
#define CHANEL2   2

XGpio   axi_gpio_inst0;      //AXI GPIO 0 driver instance
XGpio   axi_gpio_inst1;      //AXI GPIO 1 driver instance
XGpio   axi_gpio_inst2;      //AXI GPIO 2 driver instance

//AXI GPIO init
void axi_gpio_init(void)
{
    //AXI GPIO 0 driver
    XGpio_Initialize(&axi_gpio_inst0, AXI_GPIO_0_ID);
    XGpio_Initialize(&axi_gpio_inst1, AXI_GPIO_1_ID);
    XGpio_Initialize(&axi_gpio_inst2, AXI_GPIO_2_ID);
    //set AXI GPIO 0 use channel 1 and 2 for output
    XGpio_SetDataDirection(&axi_gpio_inst0, CHANEL1,0);
    XGpio_SetDataDirection(&axi_gpio_inst0, CHANEL2,0);
    XGpio_SetDataDirection(&axi_gpio_inst1, CHANEL1,0);
    XGpio_SetDataDirection(&axi_gpio_inst1, CHANEL2,0);
    XGpio_SetDataDirection(&axi_gpio_inst2, CHANEL1,0);
    XGpio_SetDataDirection(&axi_gpio_inst2, CHANEL2,0);
}

//use AXI GPIO to get FIFO data count
//u32 get_fifo_count(void)
//{
//    u32 fifo_count = 0;
//    fifo_count = XGpio_DiscreteRead(&axi_gpio_inst0, AXI_GPIO_0_CHANEL1);
//    return fifo_count;
//}


//gpio0 Channel 1
void axi_gpio_out1(void)
{
	XGpio_DiscreteWrite(&axi_gpio_inst0, 1, 0x01);
	}
void axi_gpio_out0(void)
{
	XGpio_DiscreteWrite(&axi_gpio_inst0, 1, 0x00);
	}

//gpio0 Channel 2
void axi_gpio_write(uint32_t output_result)
{
	XGpio_DiscreteWrite(&axi_gpio_inst0, 2, output_result);
}

//gpio1 Channel 1
void axi_gpio_dma_ready(void)
{
	XGpio_DiscreteWrite(&axi_gpio_inst1, 1, 0x01);
	}
void axi_gpio_dma_unready(void)
{
	XGpio_DiscreteWrite(&axi_gpio_inst1, 1, 0x00);
	}

//gpio1 Channel 2
void axi_gpio_skip(uint32_t output_result)
{
	XGpio_DiscreteWrite(&axi_gpio_inst1, 2, output_result);
}

//gpio2 Channel 1
void axi_gpio_set(uint32_t output_result)
{
	XGpio_DiscreteWrite(&axi_gpio_inst2, 1, output_result);
}

//gpio2 Channel 2
void axi_gpio_cut(uint32_t output_result)
{
	XGpio_DiscreteWrite(&axi_gpio_inst2, 2, output_result);
}
